# ✨ JUnit5 테스트 생성 가이드

---

## 🚀 테스트 코드 생성 기본 규칙

- JUnit 5와 Gradle을 사용하여 테스트 코드 생성
- 코드 커버리지를 최대화하는 방향으로 테스트 작성
- 테스트 메서드 및 클래스 명명 규칙 준수
- Given-When-Then 패턴을 활용하여 명확한 테스트 구조 유지

## 🔍 도메인 분석 및 테스트 대상

- `io.vizend.junit5.domain` 폴더 내 Entity를 기반으로 도메인 구조 분석
- 도메인 특화 로직이 `io.vizend.junit5.service`에 존재하므로 이를 반영하여 테스트 케이스 작성
- Person 도메인에 관한 **통합 테스트 코드** 작성
- API, controller에 대한 정보는 `src/main/java/io.vizend.junit5/controller` 상대경로 디렉토리에서 참고
- service는 `src/main/java/io.vizend.junit5/service` 상대경로 디렉토리에서 참고
- repository는 `src/main/java/io.vizend.junit5/repository` 상대경로 디렉토리에서 참고

## 🏗️ 통합 테스트 코드 작성

- `src/test/java/io/vizend/junit5/integratedtest` 디렉터리에 통합 테스트 파일 생성
- Controller, Service, Repository를 포함하는 통합 테스트 코드 작성
- 기존 `OrderIntegratedTest.java` 테스트 코드의 형식에 맞춰서 테스트 코드 작성
- Controller의 각 API마다 테스트 코드 작성 (예외 처리 및 엣지 케이스 포함), controller의 api 작성 순서에 맞춰서 테스트 코드도 작성
- Service 및 Repository 계층 간의 상호작용을 검증하는 테스트 포함

    ### 테스트 클래스의 네이밍
        도메인+테스트 계층+test의 camelCase

        테스트 계층 예시 :

        통합 테스트는 "IntegratedTest"
        Controller 테스트는 "ControllerTest"
        Service 테스트는 "SerivceTest"

        클래스 네이밍 예시 : "ProductIntegratedTest"

    ### 테스트 클래스의 필드 변수
        log를 찍기위한 Log4j 필드 static final로 선언
        Repository @Autowired를 통한 DI
        MockMvc @Autowired를 통한 DI
        @BeforeAll로 생성한 테스트 데이터를 담을 도메인 List
        Json Body로 변환해줄 Object Mapper는 생성해서 선언

    ### 테스트 데이터 생성
        @BeforeAll 어노테이션을 붙여서 void setUp() 이름으로 메서드 생성
        id를 포함하지 않고 도메인 테스트 데이터 10개 임의로 생성 후
        repository에 저장하고 저장된 도메인 count 로그로 출력

    ### Create 로직에 관한 테스트 코드
        테스트 메서드 이름은 "create" + domain이름 + "test" 형식의 camelCase
        도메인을 new로 생성. 혹은 도메인을 생성하는 메서드가 있는 경우에는 임의의 데이터를 넣어서 해당 메서드로 도메인 데이터 생성
        mockMvc의 perform()으로 해당 url에 parameter, body 맞춰서 넣고
        resultActions의 응답코드가 맞는지 검증
        Create 조건이 있는 경우 success, fail 조건에 따라 2가지 통합 테스트코드 작성
    
    ### update 로직에 관한 테스트 코드
        테스트 메서드 이름은 "update" + domain이름 + "test" 형식의 camelCase
        필드 변수 도메인 리스트에서 하나 가져와서, id를 제외한 필드변수 아무거나 수정하고
        mockMvc의 perform()으로 해당 url에 parameter, body 맞춰서 넣고
        resultActions의 응답코드가 맞는지 검증
      
    ### find 로직에 관한 테스트 코드
        테스트 메서드 이름은 "find" + "by" + 찾는 조건의 필드변수 이름 + "test" 형식의 camelCase
         mockMvc의 perform()으로 해당 url에 parameter, body 맞춰서 넣고
        resultActions의 응답코드가 맞는지 검증. 단일 조회인 경우에는 resultActions에 알맞은 필드변수가 있는지 검증,
        여러개를 조회하는 경우에는 resultActions의 응답이 List인지, size가 0보다 큰지 검증
  
    ### delete 로직에 관한 테스트 코드
        테스트 메서드 이름은 "delete" + domain이름 + "test" 형식의 camelCase
        setup()에서 생성한 데이터 중 하나를 mockMvc를 통해 삭제를 요청하고, assertDoesNotThrow로 검증
        isNoContent 응답이 오는것을 검증
          
        
        
        

## 🎯 테스트 코드 품질 향상

- 도메인에 존재하는 필드만 사용했는지 확인(getter, setter 주의)
- 코드 인덴트 및 스타일 가이드 준수
- 테스트 실행 속도를 고려한 효율적인 테스트 작성
- 테스트 격리를 위해 `@TestInstance(TestInstance.Lifecycle.PER_CLASS)` 또는 `@DirtiesContext` 활용 검토
- `@ParameterizedTest`를 사용하여 다양한 입력값에 대한 테스트 수행
- 테스트 실패 시 원인을 쉽게 파악할 수 있도록 명확한 `assert` 및 로그 작성
- 누락된 import 없는지 확인하고, 누락되었으면 알맞게 추가

## 📈 코드 커버리지 향상을 위한 추가 고려 사항
- 경계값 및 예외 케이스 철저히 테스트
- Mockito 및 `@SpyBean`을 적절히 활용하여 의존성 관리

---