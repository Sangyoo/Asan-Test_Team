# ✅ JUnit 5 통합 테스트 메서드 작성 규칙 (메서드별 설명)

### 🧪 공통 전제
- MockMvc를 사용하여 실제 HTTP 요청을 보내듯 테스트한다.
- 테스트는 항상 `assertDoesNotThrow()` 또는 `assertThrows()`로 감싼다.
- 실패할 수 있는 로직은 `successTest` / `failTest` 두 개의 메서드로 분리한다.
- 응답은 항상 `status()`와 `jsonPath()`를 함께 사용하여 **정확한 동작과 응답 구조**를 확인한다.

---

### 🔍 `findAll()`
#### 목적
전체 목록을 조회하는 API가 정상 동작하고, 결과가 JSON 배열 형태로 반환되는지 확인한다.

#### 작성 규칙
- HTTP 메서드: `GET`
- URL: `/api/{resource}`
- `accept()`에 `MediaType.APPLICATION_JSON` 설정
- 예외 없이 실행되는지 `assertDoesNotThrow()`로 감싼다.
- 응답 상태는 `200 OK`여야 한다.
- 응답 본문은 `jsonPath("$").isArray()`로 배열 구조를 확인한다.

---

### 🔍 `findById()`
#### 목적
특정 ID로 데이터를 조회할 수 있는지 확인한다.

#### 작성 규칙
- HTTP 메서드: `GET`
- URL: `/api/{resource}/{id}`
- `assertDoesNotThrow()`로 감싼다.
- 응답 상태는 `200 OK`
- 응답 필드가 기대한 구조인지 `jsonPath("$.필드명")`으로 검증한다.
- 실제 테스트에서는 `@BeforeAll`에서 준비된 ID를 사용해야 한다.

---

### 🛠️ `createSuccessTest()` / `createFailTest()`
#### 목적
정상적인 요청으로 리소스를 생성할 수 있고, 잘못된 요청일 경우 예외를 발생시키는지 확인한다.

#### 작성 규칙
- HTTP 메서드: `POST`
- URL: `/api/{resource}`
- `contentType()`은 `application/json`, 본문은 `ObjectMapper`로 직렬화된 객체
- `createSuccessTest()`:
  - `assertDoesNotThrow()`로 감싼다.
  - 응답 상태는 `201 Created`
- `createFailTest()`:
  - `assertThrows(Exception.class, () -> mockMvc.perform(...))`
  - 실패 사유는 유효하지 않은 ID, 필수값 누락, 중복 등 상황에 따라 다름

---

### ✏️ `updateTest()`
#### 목적
기존 리소스를 수정할 수 있는지 확인한다.

#### 작성 규칙
- HTTP 메서드: `PUT`
- URL: `/api/{resource}/{id}`
- 본문은 수정된 객체의 JSON
- `assertDoesNotThrow()`로 감싸고 응답 상태는 `200 OK`

---

### ❌ `deleteTest()`
#### 목적
특정 ID의 리소스를 삭제할 수 있는지 확인한다.

#### 작성 규칙
- HTTP 메서드: `DELETE`
- URL: `/api/{resource}/{id}`
- `assertDoesNotThrow()`로 감싼다.
- 응답 상태는 `204 No Content`
