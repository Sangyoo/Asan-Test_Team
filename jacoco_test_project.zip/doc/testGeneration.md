# Junit5 Test Generation Rules

---

## 테스트 코드 생성은 Junit5 + gradle 테스트 코드를 생성하는 것

## 현재 생성할 target domain은 person 도메인

## src/main/java/io.vizend.junit5/domain 폴더에 있는 Entity로 도메인에 대해서 파악

## service는 src/main/java/io.vizend.junit5/service 디렉토리에서 조회해서 파악

## repository는 src/main/java/io.vizend.junit5/repository 디렉토리에서 조회해서 파악

## src/test/java/io/vizend/junit5/integratedtest에 통합 테스트 파일을 생성
- Controller, Service, Repository를 모두 사용한 통합 테스트 코드
- service는 src/main/java/io.vizend.junit5/service 디렉토리에 존재하며
- repository는 src/main/java/io.vizend.junit5/repository에 존재함
- OrderIntegratedTest.java의 테스트 코드를 참고하여 작성
- Controller의 각 API 마다 테스트 코드를 작성
- 코드 커버리지가 높은 Junit5 테스트 코드를 작성
- 도메인 특화된 로직이 각 service에 존재하므로 해당 내용 또한 분석해서 Junit5 테스트 코드 생성에 참고
- 코드의 indent 규칙을 정확히 지켜야함

## src/test/java/io/vizend/junit5/integratetest