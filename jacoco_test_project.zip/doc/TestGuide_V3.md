# ✨ JUnit 5 테스트 생성 가이드

---

## 📌 개요

- JUnit 5 및 Gradle 기반의 테스트 환경 구성
- 코드 커버리지를 극대화하는 방향으로 테스트 작성
- 명확한 명명 규칙과 구조적 패턴을 준수
- 도메인 분석은 `src/main/java/io.vizend.junit5/domain` 상대경로 디렉토리에서 참고
- API, controller에 대한 정보는 `src/main/java/io.vizend.junit5/controller` 상대경로 디렉토리에서 참고
- service는 `src/main/java/io.vizend.junit5/service` 상대경로 디렉토리에서 참고
- repository는 `src/main/java/io.vizend.junit5/repository` 상대경로 디렉토리에서 참고

---

## 🔍 도메인 분석 및 테스트 대상

- `io.vizend.junit5.domain` 폴더 내 Entity를 기반으로 도메인 구조 분석
- 도메인 특화 로직이 `io.vizend.junit5.service`에 존재하므로 이를 반영하여 테스트 케이스 작성
- Product 도메인에 관한 **통합 테스트 코드** 작성

## 🚀 테스트 기본 규칙

### ✅ 전반적 원칙

- **테스트 프레임워크**: JUnit 5
- **빌드 도구**: Gradle
- **패턴**: Given-When-Then
- **테스트 클래스 및 메서드 네이밍 규칙**
    - 클래스: `도메인 + 테스트 계층 + Test`
        - 예: `ProductIntegratedTest`
    - 메서드: `createDomainNameTest`, `updateDomainNameTest` 등 camelCase 사용

- `src/test/java/io/vizend/junit5/integratedtest` 디렉터리에 통합 테스트 파일 생성
- Controller, Service, Repository를 포함하는 통합 테스트 코드 작성
- 기존 `OrderIntegratedTest.java` 테스트 코드의 형식에 맞춰서 테스트 코드 작성
- Controller의 각 API마다 테스트 코드 작성 (예외 처리 및 엣지 케이스 포함), controller의 api 작성 순서에 맞춰서 테스트 코드도 작성
- Service 및 Repository 계층 간의 상호작용을 검증하는 테스트 포함
- 테스트 메서드에서 가장 첫줄은 "//"로 비워놓기
- 도메인에서 존재하지 않는 필드는 절대 getter, setter로 사용하지 않기

### ✅ 테스트 계층 네이밍 예시

| 계층           | 접미사           |
|----------------|------------------|
| 통합 테스트     | `IntegratedTest` |
| 컨트롤러 테스트 | `ControllerTest` |
| 서비스 테스트   | `ServiceTest`    |

---

## 🧱 통합 테스트 작성 가이드

### 🗂 디렉터리 구조

- 테스트 파일 생성할 위치:  
  `src/test/java/io/vizend/junit5/integratedtest`

### 🛠️ 테스트 클래스 구성 요소

| 항목         | 내용                                                               |
|--------------|--------------------------------------------------------------------|
| 로그 필드     | `LogManager.getLogger()`를 통한 `static final` 필드 선언             |
| DI 주입       | `@Autowired` 사용 (Repository, MockMvc 등)                         |
| 테스트 데이터 | `@BeforeAll` 사용하여 도메인 데이터 리스트 생성                     |
| JSON 처리     | `ObjectMapper` 인스턴스 생성                                       |

---

### 🧪 테스트 데이터 생성 규칙

- 메서드명: `void setUp()`
- 어노테이션: `@BeforeAll`
- 도메인 인스턴스 10개를 new 생성자로 생성하고 repository에 저장.
예시 ) long 타입인데 String 넣지 않기
- 저장 완료 후 로그로 count 출력

---

## 🧪 기능별 테스트 작성 가이드

### ➕ Create

- 메서드명: `create<도메인이름>Test`
- 도메인 객체 `new`로 생성 (또는 팩토리 메서드 활용)
- `MockMvc.perform()`을 사용해 API 호출
- `status().isCreated()` 또는 조건에 따라 응답 검증
- **create인 경우에만 성공 / 실패 조건을 나눠 각각 테스트 작성**

### 🔄 Update

- 메서드명: `update<도메인이름>Test`
- `setUp()`에서 생성한 리스트에서 하나 선택 → 필드 값 수정
- 수정된 값을 body로 넣고 `MockMvc.perform()` 수행
- 적절한 응답코드 검증

### 🔍 Find

- 메서드명: `findBy<필드이름>Test`
- 단일 조회
    - `jsonPath()`로 필드 존재 여부 검증
- 다중 조회
    - 응답이 리스트인지 확인
    - 리스트의 size > 0 검증


### ❌ Delete

- 메서드명: `delete<도메인이름>Test`
- `setUp()`에서 생성한 도메인 중 하나 선택하여 삭제 요청
- `assertDoesNotThrow()` 및 `status().isNoContent()` 검증

---

## 🎯 테스트 품질 향상 체크리스트

- 도메인에 존재하지 않는 필드를 사용했는지 검토하고, 해당 내용 삭제 (매우중요)
- 코드 스타일 및 인덴트 준수
- 테스트 실행 속도 최적화
- 테스트 격리 보장
    - `@TestInstance(TestInstance.Lifecycle.PER_CLASS)`
    - 또는 `@DirtiesContext` 사용 검토
- 다양한 입력값 테스트: `@ParameterizedTest`
- 실패 시 명확한 assert와 로그 작성
- 컴파일 오류 확인하여 수정
- 존재하는 API의 경우에만 테스트 코드를 작성하였는지 확인하고 수정
- 인스턴스 생성시 생성자 파라미터 타입을 체크하여 올바른 데이터 생성했는지 검토
---

## 📈 코드 커버리지 향상 전략

- 경계값 및 예외 케이스 철저히 테스트
- `@SpyBean`, `Mockito` 등을 활용한 의존성 분리 및 모킹

---
