# ✅ JUnit 5 통합 테스트 작성 규칙

---

## 🏗️ 테스트 클래스 구조

- 어노테이션 구성:
  - `@SpringBootTest`
  - `@AutoConfigureMockMvc`
  - `@TestInstance(TestInstance.Lifecycle.PER_CLASS)`
- 클래스명은 `도메인명 + IntegratedTest` 형태로 작성 (`UserIntegratedTest`, `ProductIntegratedTest` 등)
- 로깅은 `Logger log = LogManager.getLogger(클래스명.class)` 사용
- 테스트 클래스는 테스트 대상이 되는 리포지토리와 `MockMvc`, `ObjectMapper`를 `@Autowired` 또는 직접 초기화로 주입

---

## 🧾 테스트 메서드 이름 규칙

- 기본적으로 **의도를 명확히 표현**
- 성공과 실패는 다음처럼 메서드를 분리:
  - `createSuccessTest()`, `createFailTest()`
- 기본 메서드명 예시:
  - 전체 조회: `findAllTest()`
  - 단건 조회: `findByIdTest()`
  - 생성: `createSuccessTest()`, `createFailTest()`
  - 수정: `updateTest()`
  - 삭제: `deleteTest()`

---

## 🧩 필드 변수 생성 규칙

- 테스트에서 사용할 도메인 엔티티는 리스트로 보관
  - 예: `List<Person> people`, `List<Product> products`
- 엔티티 리포지토리는 `@Autowired`로 주입
- `ObjectMapper`는 인스턴스로 선언 (`private final ObjectMapper objectMapper = new ObjectMapper();`)

---

## ⚙️ @BeforeAll 데이터 셋업 규칙

- 실제 테스트에 사용할 엔티티들을 `List.of(...)`로 10개 내외로 생성
- 엔티티 간 참조가 필요한 경우, 순차적으로 save
  1. Person → Product → Order 순으로 저장
- 저장 후 로그 출력으로 확인:
  ```java
  log.info("{} person saved", people.size());
  ```
- ID는 명시적으로 부여하여 테스트 시 조회 ID를 예측 가능하게 만든다 (`1L`, `2L` 등)

---

## 💡 API 테스트 메서드 규칙

---

### 🔍 findAllTest()

- 목적: 전체 목록이 JSON 배열로 응답되는지 확인
- 요청:
  ```java
  mockMvc.perform(get("/api/resource").accept(MediaType.APPLICATION_JSON))
  ```
- 검증:
  - 예외 없이 실행되는지 `assertDoesNotThrow()`
  - 상태 코드: `200 OK`
  - 응답 구조: `jsonPath("$").isArray()`

---

### 🔍 findByIdTest()

- 목적: ID로 단일 항목 조회
- 요청:
  ```java
  mockMvc.perform(get("/api/resource/{id}", 3L).accept(MediaType.APPLICATION_JSON))
  ```
- 검증:
  - 예외 없이 실행되는지 `assertDoesNotThrow()`
  - 상태 코드: `200 OK`
  - 응답 필드 확인: `jsonPath("$.필드명").value("기대값")`

---

### 🛠️ createSuccessTest() / createFailTest()

- 목적: 리소스를 정상적으로 생성하거나, 실패 케이스 확인
- 요청:
  ```java
  mockMvc.perform(post("/api/resource")
      .contentType(MediaType.APPLICATION_JSON)
      .content(objectMapper.writeValueAsString(객체)))
  ```
- 성공:
  - `assertDoesNotThrow()`로 감싸고
  - 응답 코드: `201 Created`
- 실패:
  - `assertThrows(Exception.class, ...)`
  - ID 불일치 등으로 의도적 실패 유도

---

### ✏️ updateTest()

- 목적: 리소스를 수정
- 요청:
  ```java
  mockMvc.perform(put("/api/resource/{id}", 1L)
      .contentType(MediaType.APPLICATION_JSON)
      .content(objectMapper.writeValueAsString(수정된객체)))
  ```
- 검증:
  - `assertDoesNotThrow()`
  - 상태 코드: `200 OK`

---

### ❌ deleteTest()

- 목적: 리소스를 삭제
- 요청:
  ```java
  mockMvc.perform(delete("/api/resource/{id}", 1L))
  ```
- 검증:
  - `assertDoesNotThrow()`
  - 상태 코드: `204 No Content`

---

## 🎯 테스트 코드 품질 향상

- 도메인에 존재하는 필드만 사용했는지 확인(getter, setter 주의)
- 코드 인덴트 및 스타일 가이드 준수
- 테스트 실행 속도를 고려한 효율적인 테스트 작성
- 테스트 격리를 위해 `@TestInstance(TestInstance.Lifecycle.PER_CLASS)` 또는 `@DirtiesContext` 활용 검토
- `@ParameterizedTest`를 사용하여 다양한 입력값에 대한 테스트 수행

## 📈 코드 커버리지 향상을 위한 추가 고려 사항
- 경계값 및 예외 케이스 철저히 테스트
- Mockito 및 `@SpyBean`을 적절히 활용하여 의존성 관리

## 테스트 조건

- 현재 Product 도메인에  관련한 통합 테스트 코드만 작성