# ✅ JUnit 5 통합 테스트 작성 규칙 (Markdown 설명)

### 📌 개요
이 문서는 JUnit 5 기반의 통합 테스트를 작성할 때 **일관된 형식**으로 코드를 생성하기 위한 규칙을 설명한다.  
특히, Spring Boot와 MockMvc를 활용해 컨트롤러(API)를 테스트하는 구조를 기준으로 한다.  
AI가 테스트 코드를 자동 생성할 때, 본 문서를 참고하여 **항상 동일한 구조와 스타일**을 유지하도록 한다.

---

### 🔧 기술 스택
- JUnit 5 (`@Test`, `@BeforeAll`, `assertDoesNotThrow`, `assertThrows`)
- Spring Boot (`@SpringBootTest`, DI 기반 Repository 사용)
- MockMvc (`@AutoConfigureMockMvc` + `MockMvc` 주입)
- Jackson (`ObjectMapper`로 JSON 직렬화)

---

### 🧱 테스트 클래스 구성 규칙

1. **클래스 선언**
   - `@SpringBootTest`, `@AutoConfigureMockMvc`, `@TestInstance(TestInstance.Lifecycle.PER_CLASS)` 어노테이션을 붙인다.
   - 클래스명은 `엔티티명IntegratedTest` 형태로 작성한다.

2. **필드 선언**
   - `Repository`와 `MockMvc`는 모두 `@Autowired`로 주입한다.
   - 테스트용 데이터를 담을 `List<엔티티>` 필드들을 선언한다.
   - `ObjectMapper`는 객체로 선언하고 초기화한다.

3. **데이터 준비**
   - `@BeforeAll` 메서드에서 더미 데이터를 생성하고 각 Repository에 저장한다.
   - 각 엔티티는 최소 10개씩 생성하고 `saveAll`을 통해 저장한다.
   - 로그를 출력하여 데이터 생성 상태를 확인할 수 있도록 한다.

4. **테스트 메서드 작성**
   - 각 메서드는 `@Test`로 선언한다.
   - `mockMvc.perform()` 호출은 `assertDoesNotThrow`로 감싼다.
   - 응답 검증은 `status().isOk()` 같은 상태 체크와, `jsonPath("$.필드명")`으로 내용 체크를 함께 한다.
   - 실패 테스트는 `assertThrows`를 사용하여 예외 발생 여부를 검증한다.

5. **테스트 메서드 종류**
   - `findAll()` : 전체 조회 테스트
        
        목적 : GET /api/orders API가 정상적으로 전체 Order 데이터를 배열(JSON Array) 형태로 반환하는지 검증한다.

        **작성 규칙**
                
        * 메서드 선언

            메서드 이름은 findAll()로 명명한다.

            @Test 어노테이션을 붙여 테스트 메서임을 명시한다.

        * 예외 방지 래핑

            mockMvc.perform() 요청 코드를 assertDoesNotThrow()로 감싸 예외 발생 여부를 검증한다.

            예외 없이 정상 수행되었는지를 assertDoesNotThrow()를 통해 명확히 표현한다.

        * 요청 방식

            GET 요청을 보낸다.

            URL은 /api/orders로 고정한다.

            accept() 메서드를 통해 클라이언트가 application/json 형태의 응답을 기대함을 명시한다.

            
        * 응답 검증

            응답의 HTTP 상태가 200 OK인지 검증한다 (status().isOk()).

            응답 본문이 JSON 배열 구조인지 확인한다 (jsonPath("$").isArray()).

            추가 고려사항

            이 테스트는 응답 데이터의 내용까지는 확인하지 않고, 응답 구조와 상태만 확인한다.

            데이터는 @BeforeAll에서 미리 저장되었기 때문에, 이 API는 최소 10개의 데이터를 반환해야 한다는 기대가 암묵적으로 존재한다.

        - `findById()` : 특정 ID로 조회 (jsonPath로 특정 필드 값 체크)


        - `createSuccessOrder()` : 정상 생성
        - `createFailOrder()` : 실패 케이스 (ID 충돌 등)
        - `updateOrder()` : 수정 테스트
        - `deleteOrder()` : 삭제 테스트

6. **기타 사항**
   - 테스트 데이터는 DB에 실제로 저장되며, 테스트 종료 후 자동으로 삭제된다 (`@SpringBootTest`의 기본 동작).
   - 메서드 네이밍은 의미를 명확하게 표현한다.
   - `// given`, `// when`, `// then` 구조로 주석을 나눠도 좋다.
