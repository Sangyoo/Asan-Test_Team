# 시작 가이드

## Junit5 가이드

### 1. Controller 테스트

#### Test Class에 ExtendWith(MockitoExtension.class) 어노테이션 추가
#### Controller를 클래스 필드 변수로 선언하고 @InjectMocks 어노테이션 추가
#### Service를 클래스 필드 변수로 선언하고 @Mock 어노테이션 추가
#### private MockMvc 추가하고 생성자로 주입
#### movckMvc.perform()으로 테스트


## Jacoco

### 전체 junit test 실행
```powershell
./gradlew clean test
```