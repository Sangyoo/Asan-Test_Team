DROP TABLE IF EXISTS customers;
CREATE TABLE customers (id SERIAL PRIMARY KEY, first_name VARCHAR(255), last_name VARCHAR(255), email VARCHAR(255));

-- 모든 데이터를 삭제하는 SQL 명령어
DELETE FROM customers;