package io.vizend.junit5.service;

import io.vizend.junit5.domain.Order;
import io.vizend.junit5.domain.Person;
import io.vizend.junit5.domain.Product;
import io.vizend.junit5.domain.cdo.OrderCdo;
import io.vizend.junit5.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final ProductService productService;
    private final PersonService  personService;
    private final OrderRepository orderRepository;

    public List<Order> getAllOrders() {
        //
        return orderRepository.findAll();
    }

    public Optional<Order> getOrderById(Long id) {
        //
        return Optional.ofNullable(orderRepository.findById(id).orElseThrow(() -> new NoSuchElementException("no order found")));
    }

    public boolean existsOrderByProductId(Long productId) {
        //
        return orderRepository.existsByProductId(productId);
    }

    public Order createOrder(Order order) {
        //
        return orderRepository.save(order);
    }

    public Order createOrder(OrderCdo cdo) {
        //
        Product product = productService.getProductById(cdo.getProductId());
        Person person = personService.getPersonById(cdo.getCustomerId());

        Order order = Order.from(product, person);
        return orderRepository.save(order);
    }

    public void deleteOrder(Long id) {
        orderRepository.deleteById(id);
    }

    public Order updateOrder(Long id, Order order) {
         Order existingOrder = orderRepository.findById(id).orElseThrow(() -> new NoSuchElementException("no order found"));
        order.setId(id);
        return orderRepository.save(order);
    }
}
