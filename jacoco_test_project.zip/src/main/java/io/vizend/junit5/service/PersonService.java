package io.vizend.junit5.service;

import io.vizend.junit5.domain.Person;
import io.vizend.junit5.repository.OrderRepository;
import io.vizend.junit5.repository.PersonRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class PersonService {

    private final PersonRepository personRepository;
    private final OrderRepository orderRepository;


    public List<Person> getAllPersons() {
        return personRepository.findAll();
    }

    public Person getPersonById(Long id) {
        return personRepository.findById(id).orElseThrow(() -> new NoSuchElementException("no person found"));
    }

    public Person createPerson(Person person) {
        return personRepository.save(person);
    }

    public void deletePerson(Long id) {
        //
        if(orderRepository.existsByCustomerId(id)) {
            throw new RuntimeException("order already exists");
        }
        personRepository.deleteById(id);
    }

    public Person updatePerson(Long id, Person person) {
        Person existingPerson = personRepository.findById(id).orElseThrow(() -> new NoSuchElementException("no person found"));
        person.setId(id);
        return personRepository.save(person);
    }
}
