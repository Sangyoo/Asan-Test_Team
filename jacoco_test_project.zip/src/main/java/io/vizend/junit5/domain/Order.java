package io.vizend.junit5.domain;

import io.vizend.junit5.domain.cdo.OrderCdo;
import jakarta.persistence.*;
import lombok.*;
@Entity
@Table(name = "orders")  // "order" 대신 "orders" 사용
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long customerId;
    private String customerName;
    private int quantity;
    private Long productId;
    private String productName;
    private double productPrice;

    public static Order from(Product product, Person person) {
        //
        Order order = new Order();
        order.setCustomerId(person.getId());
        order.setCustomerName(person.getName());
        order.setProductId(product.getId());
        order.setProductName(product.getName());
        order.setProductPrice(product.getPrice());
        return order;
    }
}