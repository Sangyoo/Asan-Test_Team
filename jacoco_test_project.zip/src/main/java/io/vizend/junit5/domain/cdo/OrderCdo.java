package io.vizend.junit5.domain.cdo;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class OrderCdo {
    //
    private Long customerId;
    private int quantity;
    private Long productId;
}
