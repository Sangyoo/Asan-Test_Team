package io.vizend.junit5.config;


import io.vizend.junit5.domain.Order;
import io.vizend.junit5.domain.Person;
import io.vizend.junit5.domain.Product;
import io.vizend.junit5.repository.OrderRepository;
import io.vizend.junit5.repository.PersonRepository;
import io.vizend.junit5.repository.ProductRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Slf4j
@Configuration
public class DBInit {

    @Bean
    public CommandLineRunner demo(PersonRepository personRepository,
                                  OrderRepository orderRepository,
                                  ProductRepository productRepository) {

        return (args) -> {
            // Person 데이터 10개 생성
            List<Person> persons = List.of(
                    new Person(1L, "John Doe", 25),
                    new Person(2L, "Jane Smith", 30),
                    new Person(3L, "Alice Johnson", 22),
                    new Person(4L, "Bob Brown", 28),
                    new Person(5L, "Charlie Williams", 35),
                    new Person(6L, "David Lee", 40),
                    new Person(7L, "Eve Davis", 26),
                    new Person(8L, "Frank Miller", 29),
                    new Person(9L, "Grace Wilson", 34),
                    new Person(10L, "Hannah Moore", 27)
            );

            // Product 데이터 10개 생성
            List<Product> products = List.of(
                    new Product(1L, "Laptop", 1500.00),
                    new Product(2L, "Smartphone", 800.00),
                    new Product(3L, "Tablet", 400.00),
                    new Product(4L, "Headphones", 120.00),
                    new Product(5L, "Keyboard", 50.00),
                    new Product(6L, "Mouse", 30.00),
                    new Product(7L, "Monitor", 250.00),
                    new Product(8L, "Camera", 600.00),
                    new Product(9L, "Smartwatch", 200.00),
                    new Product(10L, "Speaker", 80.00)
            );

            // Order 데이터 10개 생성 (Product와 Person 데이터를 사용하여 생성)
            List<Order> orders = List.of(
                    Order.from(products.get(0), persons.get(0)),
                    Order.from(products.get(1), persons.get(1)),
                    Order.from(products.get(2), persons.get(2)),
                    Order.from(products.get(3), persons.get(3)),
                    Order.from(products.get(4), persons.get(4)),
                    Order.from(products.get(5), persons.get(5)),
                    Order.from(products.get(6), persons.get(6)),
                    Order.from(products.get(7), persons.get(7)),
                    Order.from(products.get(8), persons.get(8)),
                    Order.from(products.get(9), persons.get(9))
            );
            log.info("Person: {} has been created", persons.size());
            log.info("Order: {} has been created", orders.size());
            log.info("Product: {} has been created", products.size());
        };
    }

}
