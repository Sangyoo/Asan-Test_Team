package io.vizend.junit5.integratedtest;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.vizend.junit5.domain.Person;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import java.util.ArrayList;
import java.util.List;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@AutoConfigureMockMvc
public class PersonIntegratedTest {

    static final Logger logger = LogManager.getLogger();

    @Autowired
    private MockMvc mockMvc;

    private ObjectMapper objectMapper = new ObjectMapper();

    private static List<Person> personList = new ArrayList<>();

    @BeforeAll
    static void setUp() throws Exception {
        //
        personList.clear();
        for (int i = 0; i < 10; i++) {
            Person person = new Person();
            person.setId((long) i);
            person.setName("Person " + i);
            personList.add(person);
        }
        logger.info("Person count: " + personList.size());
    }

    @Test
    void createPersonTest() throws Exception {
        //
        Person newPerson = new Person();
        newPerson.setId(10L);
        newPerson.setName("New Person");

        String personJson = objectMapper.writeValueAsString(newPerson);

        ResultActions result = mockMvc.perform(post("/persons")
                .contentType(MediaType.APPLICATION_JSON)
                .content(personJson));

        result.andExpect(status().isCreated());
    }

    @Test
    void updatePersonTest() throws Exception {
        //
        Person existingPerson = personList.get(0);
        existingPerson.setName("Updated Person Name");

        String personJson = objectMapper.writeValueAsString(existingPerson);

        ResultActions result = mockMvc.perform(put("/persons/" + existingPerson.getId())
                .contentType(MediaType.APPLICATION_JSON)
                .content(personJson));

        result.andExpect(status().isOk());
    }

    @Test
    void findByPersonIdTest() throws Exception {
        //
        Person existingPerson = personList.get(0);

        ResultActions result = mockMvc.perform(get("/persons/" + existingPerson.getId())
                .contentType(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.id").exists())
                .andExpect(jsonPath("$.name").exists());
    }

    @Test
    void deletePersonTest() throws Exception {
        //
        Person existingPerson = personList.get(0);

        ResultActions result = mockMvc.perform(delete("/persons/" + existingPerson.getId())
                .contentType(MediaType.APPLICATION_JSON));

        result.andExpect(status().isNoContent());
        assertDoesNotThrow(() -> {});
    }
}
