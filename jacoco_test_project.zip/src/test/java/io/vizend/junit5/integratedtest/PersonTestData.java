package io.vizend.junit5.integratedtest;

import io.vizend.junit5.domain.Person;

import java.util.List;

public class PersonTestData {
    //
    public static List<Person> generatePersonData() {
        //
        return List.of(
                new Person(null, "김철수", 20),
                new Person(null, "이영희", 30),
                new Person(null, "박민수", 40),
                new Person(null, "최수영", 50),
                new Person(null, "정지훈", 60),
                new Person(null, "장미", 25),
                new Person(null, "고돌이", 35),
                new Person(null, "홍길동", 45),
                new Person(null, "손흥민", 55),
                new Person(null, "류현진", 65)
        );
    }
}
