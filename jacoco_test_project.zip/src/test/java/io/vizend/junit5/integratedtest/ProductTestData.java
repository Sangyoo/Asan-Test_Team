package io.vizend.junit5.integratedtest;

import io.vizend.junit5.domain.Product;
import java.util.List;

public class ProductTestData {
    //
public static List<Product> generateProductData() {
        //
        return List.of(
                new Product(null, "삼성 TV", 1000000),
                new Product(null, "LG 냉장고", 2000000),
                new Product(null, "삼성 세탁기", 1500000),
                new Product(null, "LG 에어컨", 2500000),
                new Product(null, "삼성 청소기", 500000),
                new Product(null, "LG 전자레인지", 300000),
                new Product(null, "삼성 밥솥", 400000),
                new Product(null, "LG 다리미", 200000),
                new Product(null, "삼성 선풍기", 100000),
                new Product(null, "LG 가습기", 150000)
        );
    }
}
