package io.vizend.junit5.integratedtest;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.vizend.junit5.domain.Order;
import io.vizend.junit5.domain.Person;
import io.vizend.junit5.domain.Product;
import io.vizend.junit5.repository.OrderRepository;
import io.vizend.junit5.repository.PersonRepository;
import io.vizend.junit5.repository.ProductRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@AutoConfigureMockMvc
@SpringBootTest
public class OrderIntegratedTest {
    private static final Logger log = LogManager.getLogger(OrderIntegratedTest.class);
    //
    @Autowired
    private PersonRepository personRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private MockMvc mockMvc;
    private List<Order> orders;
    private List<Product> products;
    private List<Person> people;

    private ObjectMapper objectMapper = new ObjectMapper();

    @BeforeAll
    void setUp() {
        //
        people = List.of(
                new Person(1L, "John Doe", 25),
                new Person(2L, "Jane Smith", 30),
                new Person(3L, "Alice Johnson", 22),
                new Person(4L, "Bob Brown", 28),
                new Person(5L, "Charlie Williams", 35),
                new Person(6L, "David Lee", 40),
                new Person(7L, "Eve Davis", 26),
                new Person(8L, "Frank Miller", 29),
                new Person(9L, "Grace Wilson", 34),
                new Person(10L, "Hannah Moore", 27)
        );
        personRepository.saveAll(people);
        log.info("{} person saved", people.size());

        // Product 데이터 10개 생성
        products = List.of(
                new Product(1L, "Laptop", 1500.00),
                new Product(2L, "Smartphone", 800.00),
                new Product(3L, "Tablet", 400.00),
                new Product(4L, "Headphones", 120.00),
                new Product(5L, "Keyboard", 50.00),
                new Product(6L, "Mouse", 30.00),
                new Product(7L, "Monitor", 250.00),
                new Product(8L, "Camera", 600.00),
                new Product(9L, "Smartwatch", 200.00),
                new Product(10L, "Speaker", 80.00)
        );
        productRepository.saveAll(products);
        log.info("Product: {} has been created", products.size());


        // Order 데이터 10개 생성 (Product와 Person 데이터를 사용하여 생성)
        orders = List.of(
                Order.from(products.get(0), people.get(0)),
                Order.from(products.get(1), people.get(1)),
                Order.from(products.get(2), people.get(2)),
                Order.from(products.get(3), people.get(3)),
                Order.from(products.get(4), people.get(4)),
                Order.from(products.get(5), people.get(5)),
                Order.from(products.get(6), people.get(6)),
                Order.from(products.get(7), people.get(7)),
                Order.from(products.get(8), people.get(8)),
                Order.from(products.get(9), people.get(9))
        );
        orderRepository.saveAll(orders);
        log.info("Order: {} has been created", orders.size());
    }

    @Test
    public void findAll() throws Exception {
        //
        ResultActions resultActions = assertDoesNotThrow(() -> mockMvc.perform(
                MockMvcRequestBuilders.get("/api/orders")
                        .accept(MediaType.APPLICATION_JSON))
        );

        resultActions.andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray());
    }

    @Test
    public void findById() throws Exception {
        //
        long id = 3L;
        ResultActions resultActions = assertDoesNotThrow(() -> mockMvc.perform(
                MockMvcRequestBuilders.get("/api/orders/{id}", id)
                        .accept(MediaType.APPLICATION_JSON))
        );

        resultActions.andExpect(status().isOk())
                .andExpect(jsonPath("$.customerId").exists())
                .andExpect(jsonPath("$.customerName").value("Alice Johnson"));
    }

    //@Test
    void createFailOrder() throws Exception {
        // given
        Order from = Order.from(products.get(0), people.get(0));
        from.setCustomerId(12L);

        
        assertThrows(Exception.class, () -> mockMvc.perform(
               MockMvcRequestBuilders.post("/api/orders")
                       .contentType(MediaType.APPLICATION_JSON)
                       .content(objectMapper.writeValueAsString(from))
        ));
    }

    @Test
    void createSuccessOrder() throws Exception {
        // given
        Order from = Order.from(products.get(0), people.get(0));

        //
        ResultActions resultActions = assertDoesNotThrow(() -> mockMvc.perform(
                MockMvcRequestBuilders.post("/api/orders")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(from))
        ));

        resultActions.andExpect(status().isCreated());
    }

    @Test
    void updateOrder() throws Exception {
        //
        Order from = Order.from(products.get(0), people.get(0));
        
        //
        ResultActions resultActions = assertDoesNotThrow(() -> 
                mockMvc.perform(
                MockMvcRequestBuilders.put("/api/orders/{id}", 1L)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(from))
                )
        );

        resultActions.andExpect(status().isOk());
    }

    @Test
    void deleteOrder() throws Exception {
        //
        ResultActions resultActions = assertDoesNotThrow(() -> 
                mockMvc.perform(MockMvcRequestBuilders.delete("/api/orders/{id}", 1L))
        );
        resultActions.andExpect(status().isNoContent());
    }


}
