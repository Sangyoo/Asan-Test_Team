package io.vizend.junit5.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.vizend.junit5.domain.Person;
import io.vizend.junit5.service.PersonService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

//@WebMvcTest(controllers = PersonController.class)
@ExtendWith(MockitoExtension.class)
class PersonControllerTest {

    @InjectMocks
    private PersonController personController;

    @Mock
    private PersonService personService;

    private MockMvc mockMvc;

    private ObjectMapper objectMapper = new ObjectMapper();
    @BeforeEach
    void setUp() {
        //
        mockMvc = MockMvcBuilders.standaloneSetup(personController).build();
    }
//
//    @AfterEach
//    void tearDown() {
//    }

    @Test
    void getAllPersons() throws Exception {
        //
        List<Person> people = List.of(new Person(1L, "sy", 30),
                new Person(2L, "syu", 20),
                new Person(3L, "syulee", 10));
//        BDDMockito.given(personService.getAllPersons()).willReturn(people);

        //
        mockMvc.perform(MockMvcRequestBuilders.get("/api/persons")
                .accept(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsBytes(people)))
                .andExpect(status().isOk())
                .andDo(print());
    }

    @Test
    void getPersonById() throws Exception {
        //
        Person person = new Person(1L, "sy", 30);
//        BDDMockito.given(personService.getPersonById(any(Long.class))).willReturn(person);
        //
        mockMvc.perform(MockMvcRequestBuilders.get("/api/persons/")
                .param("id", "1L"))
                .andExpect(status().isOk())
                .andDo(print());
    }

    @Test
    void createPerson() throws Exception {
        //
        Person person = new Person();
        person.setName("John");

        BDDMockito.given(personService.createPerson(any(Person.class))).willReturn(person);
        //
        ResultActions perform = mockMvc.perform(MockMvcRequestBuilders.post("/api/persons")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(person)));

        MvcResult mvcResult = perform.andExpect(status().isOk())
                .andDo(print())
                .andReturn();

        System.out.println("Result value : " + mvcResult.getResponse().getContentAsString());
    }

    @Test
    void deletePerson() throws Exception {
        //
        Person person = new Person();
        person.setName("John");

        mockMvc.perform(MockMvcRequestBuilders.delete("/api/persons/{id}", 1L))
                .andExpect(status().isNoContent());
    }

    @Test
    void updatePerson() throws Exception {
        // Given
        Person updatedPerson = new Person(1L, "Updated John Doe", 31);
        BDDMockito.given(personService.updatePerson(any(Long.class), any(Person.class))).willReturn(updatedPerson);

        // When & Then
        mockMvc.perform(MockMvcRequestBuilders.put("/api/persons/{id}", 1L)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updatedPerson)))
                .andDo(print())
                .andExpect(status().isOk());
    }
}
