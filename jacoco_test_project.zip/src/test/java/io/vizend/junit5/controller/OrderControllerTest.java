package io.vizend.junit5.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.vizend.junit5.domain.Order;
import io.vizend.junit5.domain.Person;
import io.vizend.junit5.domain.Product;
import io.vizend.junit5.service.OrderService;
import org.junit.jupiter.api.BeforeEach;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.doReturn;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class OrderControllerTest {

    @InjectMocks
    private OrderController orderController;

    @Mock
    private OrderService orderService;

    private MockMvc mockMvc;

    private ObjectMapper objectMapper = new ObjectMapper();

    private Product product;

    private Person person;

    private Order order;

    @BeforeEach
    void setUp() {
        //
        mockMvc = MockMvcBuilders.standaloneSetup(orderController).build();
        product = new Product(1L, "Laptop", 1000);
        person = new Person(1L, "John Doe", 30);
        order = Order.from(product, person);
    }

    @Test
    void getAllOrders() throws Exception {
        //
//        BDDMockito.given(orderService.getAllOrders()).willReturn(List.of(order));

        //
        mockMvc.perform(MockMvcRequestBuilders.get("/api/orders")
                        .accept(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsBytes(List.of(order))))
                .andExpect(status().isOk())
                .andDo(print());
    }

    @Test
    void getOrderById() throws Exception {
        //
        mockMvc.perform(MockMvcRequestBuilders.get("/api/orders/")
                        .param("id", "1L"))
                .andExpect(status().isOk())
                .andDo(print());
    }

    @Test
    void createOrder() throws Exception {
        //
        ResultActions perform = mockMvc.perform(MockMvcRequestBuilders.post("/api/orders")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(order)));

        MvcResult mvcResult = perform.andExpect(status().isCreated())
                .andDo(print())
                .andReturn();

        System.out.println("Result value : " + mvcResult.getResponse().getContentAsString());
    }

    @Test
    void deleteOrder() throws Exception {
        //
        mockMvc.perform(MockMvcRequestBuilders.delete("/api/orders/{id}", 1L))
                .andExpect(status().isNoContent());
    }

    @Test
    void updateOrder() throws Exception {
        // Given
        Order updatedOrder = Order.from(new Product(2L, "Updated Laptop", 1200), new Person(2L, "Updated John Doe", 31));

        BDDMockito.given(orderService.updateOrder(anyLong(), any(Order.class))).willReturn(updatedOrder);        

        // When & Then
        mockMvc.perform(MockMvcRequestBuilders.put("/api/orders/{id}", 1L)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updatedOrder)))
                .andDo(print())
                .andExpect(status().isOk());
    }

}
