package io.vizend.junit5.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.vizend.junit5.domain.Product;
import io.vizend.junit5.service.ProductService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class ProductControllerTest {
    @InjectMocks
    private ProductController productController;

    @Mock
    private ProductService productService;

    private MockMvc mockMvc;

    private final Product product = new Product(1L, "Laptop", 1000);;
    private ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        //
        mockMvc = MockMvcBuilders.standaloneSetup(productController).build();
    }
    @Test
    void getAllProducts() throws Exception {
        //
        List<Product> productList = List.of(product);
        //
        mockMvc.perform(MockMvcRequestBuilders.get("/api/products")
                        .accept(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsBytes(productList)))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andDo(print());
    }

    @Test
    void getProductById() throws Exception {
        //

        //
        mockMvc.perform(MockMvcRequestBuilders.get("/api/products/")
                        .param("id", "1L"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andDo(print());
    }

    @Test
    void createProduct() throws Exception {
        //
        BDDMockito.given(productService.createProduct(any(Product.class))).willReturn(product);
        //
        mockMvc.perform(MockMvcRequestBuilders.post("/api/products")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(product)))
                .andDo(print())
                .andExpect(MockMvcResultMatchers.status().isCreated())
                .andExpect(MockMvcResultMatchers.header().doesNotExist("Location"));
    }

    @Test
    void updateProduct() throws Exception {
        // Given
        Product updatedProduct = new Product(1L, "Updated Laptop", 1200);
        BDDMockito.given(productService.updateProduct(any(Long.class), any(Product.class))).willReturn(updatedProduct);

        // When & Then
        mockMvc.perform(MockMvcRequestBuilders.put("/api/products/{id}", 1L)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updatedProduct)))
                .andDo(print())
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.name").value("Updated Laptop"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.price").value(1200));
    }

    @Test
    void deleteProduct() throws Exception {
        //
        mockMvc.perform(MockMvcRequestBuilders.delete("/api/products/{id}", 1L))
                .andExpect(status().isNoContent());
    }
}
