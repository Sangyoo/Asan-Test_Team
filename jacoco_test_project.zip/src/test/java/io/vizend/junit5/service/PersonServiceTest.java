package io.vizend.junit5.service;

import io.vizend.junit5.domain.Person;
import io.vizend.junit5.domain.Product;
import io.vizend.junit5.repository.OrderRepository;
import io.vizend.junit5.repository.PersonRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class PersonServiceTest {

    @InjectMocks
    private PersonService personService;

    @Mock
    private PersonRepository personRepository;

    @Mock
    private OrderRepository orderRepository;

    @BeforeEach
    void setUp() {
    }

    @Test
    void getAllPersons() {
        //
        Person person1 = new Person(1L, "John", 30);
        Person person2 = new Person(2L, "Samuel", 20);
        Person person3 = new Person(3L, "Catherine", 10);
        List<Person> personList = List.of(person1, person2, person3);
        BDDMockito.given(personRepository.findAll()).willReturn(personList);

        //
        List<Person> allPersons = personService.getAllPersons();

        //
        assertAll(
                "getAllPersons",
                () -> assertFalse(personList.isEmpty()),
                () -> verify(personRepository, times(1)).findAll()
        );
    }

    @Test
    void getPersonById() {
        //
        Person person = new Person();
        person.setId(1L);
        person.setName("John");
        BDDMockito.given(personRepository.findById(any(Long.class))).willReturn(Optional.of(person));
        //
        Person personById = personService.getPersonById(1L);
        //
        assertAll(
                "getPersonById",
                () -> assertNotNull(personById),
                () -> verify(personRepository, times(1)).findById(any(Long.class))
        );

    }

    @Test
    void createPerson() {
        // given
        Person person = new Person();
        person.setId(1L);
        person.setName("John");

        // stub
        BDDMockito.given(personRepository.save(person)).willReturn(person);

        // when
        Long savedId = personService.createPerson(person).getId();

        Assertions.assertEquals(savedId, person.getId());
    }

    @Test
    void deletePerson() {
        //
        Person person1 = new Person(1L, "John", 30);
        BDDMockito.given(orderRepository.existsByCustomerId(any(Long.class))).willReturn(true);

        //
        assertThrows(RuntimeException.class, () -> personService.deletePerson(person1.getId()));

        //
        BDDMockito.verify(personRepository, times(0)).delete(any(Person.class));
    }

    @Test
    void deletePersonSucess() {
        //
        Person person1 = new Person(1L, "John", 30);
        BDDMockito.given(orderRepository.existsByCustomerId(any(Long.class))).willReturn(false);

        //
        assertDoesNotThrow(() -> personService.deletePerson(person1.getId()));

        //
        BDDMockito.verify(personRepository, times(1)).deleteById(any(Long.class));
    }

    @Test
    void updatePerson() {
        // Given
        Person existingPerson = new Person(1L, "John", 30);
        Person updatedPerson = new Person(1L, "Updated John Doe", 31);
        BDDMockito.given(personRepository.findById(1L)).willReturn(Optional.of(existingPerson));
        BDDMockito.given(personRepository.save(any(Person.class))).willReturn(updatedPerson);

        // When
        Person result = personService.updatePerson(1L, updatedPerson);

        // Then
        assertAll("updatePerson",
                () -> assertNotNull(result),
                () -> assertEquals("Updated John Doe", result.getName()),
                () -> assertEquals(31, result.getAge()),
                () -> verify(personRepository, times(1)).findById(1L),
                () -> verify(personRepository, times(1)).save(any(Person.class))
        );
    }
}
