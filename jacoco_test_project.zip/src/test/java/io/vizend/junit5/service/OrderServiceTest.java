package io.vizend.junit5.service;

import io.vizend.junit5.domain.Order;
import io.vizend.junit5.domain.Person;
import io.vizend.junit5.domain.Product;
import io.vizend.junit5.domain.cdo.OrderCdo;
import io.vizend.junit5.repository.OrderRepository;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OrderServiceTest {
    //
    @Mock
    private ProductService productService;

    @Mock
    private PersonService personService;

    @Mock
    private OrderRepository orderRepository;

    @InjectMocks
    private OrderService orderService;

    private Order order;
    private Product product;
    private Person person;

    @BeforeEach
    void setUp() {
        //
        product = new Product(1L, "Laptop", 1000);
        person = new Person(1L, "John Doe", 30);
        order = Order.from(product, person);
    }

    @Test
    void getAllOrders() {
        // Given
        when(orderRepository.findAll()).thenReturn(List.of(order));

        // When
        List<Order> orders = orderService.getAllOrders();

        // Then
        assertNotNull(orders);
        assertEquals(1, orders.size());
        assertEquals(order.getProductName(), orders.get(0).getProductName());

        // findAll이 호출되었는지 확인
        verify(orderRepository, times(1)).findAll();

    }

    @Test
    void getOrderById() {
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));

        // When
        Optional<Order> foundOrder = orderService.getOrderById(1L);

        // Then
        assertTrue(foundOrder.isPresent());
        assertEquals(order.getProductName(), foundOrder.get().getProductName());

        verify(orderRepository, times(1)).findById(1L); // findById가 호출되었는지 확인
    }

    @Test
    void createOrder() {
        // Given
        BDDMockito.given(orderRepository.save(any(Order.class))).willReturn(order);

        // when
        Long savedId = orderService.createOrder(order).getId();

        Assertions.assertEquals(savedId, order.getId());
    }

    @Test
    void testCreateOrder() {
        // Given
        when(orderRepository.save(order)).thenReturn(order);

        // When
        Order createdOrder = orderService.createOrder(order);

        // Then
        assertNotNull(createdOrder);
        assertEquals(order.getProductName(), createdOrder.getProductName());
        verify(orderRepository, times(1)).save(order); // save가 호출되었는지 확인
    }

    @Test
    void deleteOrder() {
        // Given
        OrderCdo cdo = new OrderCdo(1L, 15, 1L);  // Product ID와 Customer ID를 포함하는 Cdo
        when(productService.getProductById(1L)).thenReturn(product);
        when(personService.getPersonById(1L)).thenReturn(person);
        when(orderRepository.save(any(Order.class))).thenReturn(order);

        // When
        Order createdOrder = orderService.createOrder(cdo);

        // Then
        assertNotNull(createdOrder);
        assertEquals(product.getName(), createdOrder.getProductName());
        assertEquals(person.getName(), createdOrder.getCustomerName());
        verify(productService, times(1)).getProductById(1L);  // getProductById가 호출되었는지 확인
        verify(personService, times(1)).getPersonById(1L);    // getPersonById가 호출되었는지 확인
        verify(orderRepository, times(1)).save(any(Order.class));  // save가 호출되었는지 확인
    }

    @Test
    void updateOrder() {
        // Given
        Order updatedOrder = Order.from(new Product(2L, "Updated Laptop", 1200), new Person(2L, "Updated John Doe", 31));
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        when(orderRepository.save(any(Order.class))).thenReturn(updatedOrder);

        // When
        Order result = orderService.updateOrder(1L, updatedOrder);

        // Then
        assertNotNull(result);
        assertEquals("Updated Laptop", result.getProductName());
        assertEquals("Updated John Doe", result.getCustomerName());
        verify(orderRepository, times(1)).findById(1L);
        verify(orderRepository, times(1)).save(any(Order.class));
    }
}
