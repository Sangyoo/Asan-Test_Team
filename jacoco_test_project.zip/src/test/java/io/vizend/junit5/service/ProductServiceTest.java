package io.vizend.junit5.service;

import io.vizend.junit5.domain.Order;
import io.vizend.junit5.domain.Product;
import io.vizend.junit5.repository.OrderRepository;
import io.vizend.junit5.repository.ProductRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static reactor.core.publisher.Mono.when;

@ExtendWith(MockitoExtension.class)
class ProductServiceTest {
    @InjectMocks
    private ProductService productService;

    @Mock
    private ProductRepository productRepository;

    @Mock
    private OrderService orderService;

    @Mock
    private OrderRepository orderRepository;

    @Mock
    private Order order;

    @BeforeEach
    void setUp() {
    }

    @Test
    void getAllProducts() {
        //
        Product product1 = new Product(1L, "Laptop", 1000);
        Product product2 = new Product(2L, "Desktop", 2000);
        Product product3 = new Product(3L, "NoteBook", 3000);
        BDDMockito.given(productRepository.findAll()).willReturn(List.of(product1, product2, product3));

        //
        List<Product> allProducts = productService.getAllProducts();

        //
        assertAll("getAllProducts", () -> assertEquals(3, allProducts.size()), () -> verify(productRepository, times(1)).findAll());

    }

    @Test
    void getProductById() {
        //
        Product product = new Product(1L, "Laptop", 1000);
        BDDMockito.given(productRepository.findById(any(Long.class))).willReturn(Optional.of(product));

        //
        Product productById = productService.getProductById(1L);
        //
        assertAll(
                "getProductById",
                () -> assertNotNull(productById),
                () -> verify(productRepository, times(1)).findById(any(Long.class))
                );
    }

    @Test
    void createProduct() {
        //
        Product product = new Product(1L, "Laptop", 1000);
        BDDMockito.given(productRepository.save(any(Product.class))).willReturn(product);

        //
        Product created = productService.createProduct(product);

        //
        assertNotNull(created);
        assertEquals(product.getId(), created.getId());
        BDDMockito.verify(productRepository, times(1)).save(any(Product.class));
    }

    @Test
    void deleteProduct() {
        // given
        Product product = new Product(1L, "product", 1200.0);
        BDDMockito.given(orderRepository.existsByProductId(any(Long.class))).willReturn(true);

        //
        assertThrows(RuntimeException.class, () -> productService.deleteProduct(product.getId()));
//        assertDoesNotThrow(() -> productService.deleteProduct(product.getId()));

        //
        BDDMockito.verify(productRepository, times(0)).delete(any(Product.class));
    }

    @Test
    void deleteProductSuccess() {
        // given
        Product product = new Product(1L, "product", 1200.0);
        BDDMockito.given(orderRepository.existsByProductId(any(Long.class))).willReturn(false);

        // when
        assertDoesNotThrow(() -> productService.deleteProduct(product.getId()));
//        assertDoesNotThrow(() -> productService.deleteProduct(product.getId()));

        // then
        BDDMockito.verify(productRepository, times(1)).deleteById(any(Long.class));
    }

    @Test
    void updateProduct() {
        // Given
        Product existingProduct = new Product(1L, "Laptop", 1000);
        Product updatedProduct = new Product(1L, "Updated Laptop", 1200);
        BDDMockito.given(productRepository.findById(1L)).willReturn(Optional.of(existingProduct));
        BDDMockito.given(productRepository.save(any(Product.class))).willReturn(updatedProduct);

        // When
        Product result = productService.updateProduct(1L, updatedProduct);

        // Then
        assertAll("updateProduct",
                () -> assertNotNull(result),
                () -> assertEquals("Updated Laptop", result.getName()),
                () -> assertEquals(1200, result.getPrice()),
                () -> verify(productRepository, times(1)).findById(1L),
                () -> verify(productRepository, times(1)).save(any(Product.class))
        );
    }
}
