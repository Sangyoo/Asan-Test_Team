package io.vizend.accountmcpserver.repository;

import io.vizend.accountmcpserver.domain.Account;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class InitialData implements CommandLineRunner{
    //
    private final AccountRepository accountRepository;

    @Override
    public void run(String... args) {
        // 초기 데이터 생성
        Account account1 = new Account();
        account1.setNumber("123-456-7890");
        account1.setBalance(1000);
        account1.setPersonId(1L);

        Account account2 = new Account();
        account2.setNumber("987-654-3210");
        account2.setBalance(2000);
        account2.setPersonId(2L);

        // 데이터를 저장
        accountRepository.save(account1);
        accountRepository.save(account2);

        log.info("초기 데이터가 저장되었습니다.");
    }
}
