package io.vizend.accountmcpserver.service;

public class TestService {
}
