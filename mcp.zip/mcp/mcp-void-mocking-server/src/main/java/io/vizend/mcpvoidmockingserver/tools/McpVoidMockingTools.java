package io.vizend.mcpvoidmockingserver.tools;

import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class McpVoidMockingTools {
    //
    private final String WHEN_PARAMETER_FORMAT = "any(%s.class)";
    private final String doNothingFormat = "Mockito.doNothing().when(%s).%s(%s);";

    @Tool(
            description = "Generate Mockito.doNothing().when().method() From Class Instance, Method Name, " +
                    "Method Parameter ClassName List.",
            name = "GenerateVoidMocking"
    )
    public String generateMockingReturn(
            @ToolParam(description = "Class Instance") String classInstance,
            @ToolParam(description = "Method Name") String methodName,
            @ToolParam(description = "Method Parameter ClassName List") List<String> methodParameterClassNameList
    ) {
        //
        String methodParameterExpr = methodParameterClassNameList.stream()
                .map(parameter -> String.format(WHEN_PARAMETER_FORMAT, parameter))
                .collect(Collectors.joining(", "));

        return String.format(doNothingFormat, classInstance, methodName, methodParameterExpr);
    }
}
