package io.vizend.mcpreturnmockingserver.tools;

import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class McpReturnMockingTools {
    //
    private final String WHEN_PARAMETER_FORMAT = "any(%s.class)";
    private final String WHEN_RETURN_SAMPLE_FORMAT = "Mockito.when(%s.%s(%s)).thenReturn(%s.sample());";
    private final String WHEN_RETURN_EXAMPLE_FORMAT = "Mockito.when(%s.%s(%s)).thenReturn(%s);";

    @Tool(
            description = "Generate Mockito.when().thenReturn() expression From Class Instance, Method Name, " +
                    "Method Parameter ClassName List, Method Return Type Class Name when method returns reference type except for String class.",
            name = "GenerateReferenceReturnMocking"
    )
    public String generateMockingReferenceReturn(
            @ToolParam(description = "Class Instance") String classInstance,
            @ToolParam(description = "Method Name") String methodName,
            @ToolParam(description = "Method Parameter ClassName List") List<String> methodParameterClassNameList,
            @ToolParam(description = "Method Return Type Class Name") String methodReturnTypeClassName
    ) {
        //
        String methodParameterExpr = methodParameterClassNameList.stream()
                .map(parameter -> String.format(WHEN_PARAMETER_FORMAT, parameter))
                .collect(Collectors.joining(", "));

        return String.format(WHEN_RETURN_SAMPLE_FORMAT, classInstance, methodName, methodParameterExpr, methodReturnTypeClassName);
    }

    @Tool(
            description = "Generate Mockito.when().thenReturn() expression From Class Instance, Method Name, " +
                    "Method Parameter ClassName List, Method Return Example when method returns primitive, String, Wrapper type.",
            name = "GeneratePrimitiveReturnMocking"
    )
    public String generateMockingPrimitiveReturn(
            @ToolParam(description = "Class Instance") String classInstance,
            @ToolParam(description = "Method Name") String methodName,
            @ToolParam(description = "Method Parameter ClassName List") List<String> methodParameterClassNameList,
            @ToolParam(description = "Method Return Example") String methodReturnExample
    ) {
        //
        String methodParameterExpr = methodParameterClassNameList.stream()
                .map(parameter -> String.format(WHEN_PARAMETER_FORMAT, parameter))
                .collect(Collectors.joining(", "));

        return String.format(WHEN_RETURN_EXAMPLE_FORMAT, classInstance, methodName, methodParameterExpr, methodReturnExample);
    }
}
