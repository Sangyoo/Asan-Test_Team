package io.vizend.mcpserverperson.respoitory;

import io.vizend.mcpserverperson.domain.Gender;
import io.vizend.mcpserverperson.domain.Person;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class InitialData implements CommandLineRunner{
    //
    private final PersonRepository personRepository;

    @Override
    public void run(String... args) {
        // 초기 데이터 생성
        List.of(
                new Person(null, "John", "Doe", 30, "USA", Gender.MALE),
                new Person(null, "Jane", "Doe", 28, "Canada", Gender.FEMALE),
                new Person(null, "Alex", "Smith", 35, "UK", Gender.MALE),
                new Person(null, "Mary", "Johnson", 40, "Australia", Gender.FEMALE)
        ).forEach(personRepository::save);

        log.info("Person 초기 데이터가 저장되었습니다.");
    }
}
