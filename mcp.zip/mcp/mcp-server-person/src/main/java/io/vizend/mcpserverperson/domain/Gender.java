package io.vizend.mcpserverperson.domain;

public enum Gender {
    MALE,
    FEMALE
}
