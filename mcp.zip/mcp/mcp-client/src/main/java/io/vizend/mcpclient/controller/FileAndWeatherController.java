package io.vizend.mcpclient.controller;

import io.modelcontextprotocol.client.McpSyncClient;
import io.modelcontextprotocol.spec.McpSchema;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.chat.prompt.PromptTemplate;
import org.springframework.ai.ollama.OllamaChatModel;
import org.springframework.ai.tool.ToolCallbackProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/persons")
@Slf4j
public class FileAndWeatherController {
    //
    private final static Logger LOG = LoggerFactory.getLogger(PersonController.class);
    private final OllamaChatModel ollamaChatModel;
    private final ToolCallbackProvider tools;

    //    @Autowired
//    private List<McpAsyncClient> mcpAsyncClients;
    @Autowired
    private List<McpSyncClient> mcpSyncClients;

    public FileAndWeatherController(OllamaChatModel ollamaChatModel,
                               /* @Qualifier("toolCallbackProvider")*/ ToolCallbackProvider tools) {
        this.ollamaChatModel = ollamaChatModel;
        int length = tools.getToolCallbacks().length;
        log.info("tool size : {}", length);
        this.tools = tools;
    }

    @GetMapping("/command/{prompt}")
    String fileCommand(@PathVariable String prompt) {
        PromptTemplate promptTemplate = new PromptTemplate("""
                use file system tools, {prompt} ?
                """);
        Prompt p = promptTemplate.create(Map.of("prompt", prompt));
        String result = ChatClient.builder(ollamaChatModel)
                .defaultTools(tools)
                .build()
                .prompt(p)
                .call()
                .content();
        return result;
    }

    @GetMapping("/weather/{prompt}")
    String weatherCommand(@PathVariable String prompt) {
        PromptTemplate promptTemplate = new PromptTemplate("""
                use weather forecast tools, how's the weather in {prompt} ?
                """);
        Prompt p = promptTemplate.create(Map.of("prompt", prompt));
        String result = ChatClient.builder(ollamaChatModel)
                .defaultTools(tools)
                .build()
                .prompt(p)
                .call()
                .content();
        log.info("weather result : {}", result);
        return result;
    }

    Prompt loadPromptByName(String name, String nationality) {
        McpSchema.GetPromptRequest r = new McpSchema.GetPromptRequest(name, Map.of("nationality", nationality));
//        var client = mcpAsyncClients.stream()
        var client = mcpSyncClients.stream()
                .filter(c -> c.getServerInfo().name().equals("person-mcp-server"))
                .findFirst();
        if (client.isPresent()) {
//            var content = (McpSchema.TextContent) client.get().getPrompt(r).block().messages().getFirst().content();
            var content = (McpSchema.TextContent) client.get().getPrompt(r).messages().getFirst().content();
            PromptTemplate pt = new PromptTemplate(content.text());
            Prompt p = pt.create(Map.of("nationality", nationality));
            LOG.info("Prompt: {}", p);
            return p;
        } else return null;
    }
}
