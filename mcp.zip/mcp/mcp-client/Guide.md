# MCP Client

## MCP Server 등록하는 법

### 1. Stdio
```yaml
spring:
    mcp:
      client:
        toolcallback:
          enabled: true
        type: SYNC
        stdio:
          root-change-notification: false
          connections:
            fileSystem:
              command: C:\\nvm4w\\nodejs\\npx.cmd
              args:
                - "-y"
                - "@modelcontextprotocol/server-filesystem"
                - "C:\\"
                - "D:\\"
            server_time:
              command: uv
              args:
                - "--directory"
                - "D:\\Mcp-server-github\\servers-main\\src\\time\\src\\mcp_server_time"
                - "run"
                - "__main__.py"
                - "--local-timezone=America/New_York"
```
위와 같이 yml 파일 작성.


### 2. HTTP / WEBFLUX
```yaml
spring:
    mcp:
      client:
        toolcallback:
          enabled: true
        type: SYNC
        sse:
          # type: WEBFLUX
          connections:
            person-mcp-server:
              url: http://localhost:8060
            account-mcp-server:
              url: http://localhost:8040
```
Sync/Async는 MCP Server 설정에 맞추기

HTTP/WEBFLUX 또한 MCP Server 설정에 맞추기