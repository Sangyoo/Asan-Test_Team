def main():
    print("Hello from weather!")


if __name__ == "__main__":
    main()
