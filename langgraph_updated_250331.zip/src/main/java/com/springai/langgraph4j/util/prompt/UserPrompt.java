package com.springai.langgraph4j.util.prompt;

public class UserPrompt {
    //
    public static String RouterUserPromptFormat = """
            You are an expert at routing a user question to a vectorstore or web search.
                        
            The vectorstore contains documents related to %s.
                        
            Use the vectorstore for questions on these topics. For all else, and especially for current events, use web-search.
                        
            Return JSON with single key, datasource, that is 'websearch' or 'vectorstore' depending on the question.
            """;
    public static String GradeUserPromptFormat = """
                Here is the retrieved document: \n\n %s \n\n Here is the user question: \n\n %s.
                This carefully and objectively assess whether the document contains at least some information that is relevant to the question.
                Return JSON with single key, binary_score, that is 'yes' or 'no' score to indicate whether the document contains at least some information that is relevant to the question.
                """;
    public static String GeneratePromptFormat = """
                ""\"You are an assistant for question-answering tasks.\s

                Here is the context to use to answer the question:

                %s\s

                Think carefully about the above context.\s

                Now, review the user question:

                %s

                Provide an answer to this questions using only the above context.\s

                Use three sentences maximum and keep the answer concise.

                Answer:""\"
                """;

    public static String CheckHallucUserPromptFormat = """
                FACTS: \\n\\n %s \\n\\n STUDENT ANSWER: %s.\s
                
                Return JSON with two two keys, binary_score is 'yes' or 'no' score to indicate whether the STUDENT ANSWER 
                is grounded in the FACTS. And a key, explanation, that contains an explanation of the score.
                """;
}
