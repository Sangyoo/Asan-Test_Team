package com.springai.langgraph4j.util.document.tranformer;

import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.document.Document;
import org.springframework.ai.transformer.splitter.TokenTextSplitter;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
@Slf4j
public class CustomTokenTextSplitter {
    //
    public List<Document> splitDocuments(List<Document> documents) {
        TokenTextSplitter splitter = new TokenTextSplitter();
        return splitter.apply(documents);
    }

    public List<Document> splitCustomized(List<Document> documents) {
        TokenTextSplitter splitter = new TokenTextSplitter(
                1000,
                400,
                10,
                5000,
                true);
        return splitter.apply(documents);
    }

    public static void main(String[] args) {
        TokenTextSplitter splitter = new TokenTextSplitter(
                1000,
                400,
                10,
                -1,
                true);
        Document doc1 = new Document("This is a long piece of text that needs to be split into smaller chunks for processing.",
                Map.of("source", "example.txt"));
        Document doc2 = new Document("Another document with content that will be split based on token count.",
                Map.of("source", "example2.txt"));

        List<Document> splitDocuments = splitter.apply(List.of(doc1, doc2));

        for (Document doc : splitDocuments) {
            log.info("Chunk: " + doc.getFormattedContent());
            log.info("Metadata: " + doc.getMetadata());
        }
    }
}
