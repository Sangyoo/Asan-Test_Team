package com.springai.langgraph4j.util.prompt;

public class SystemPrompt {
    //
    public static String GradeSystemPrompt = """
                You are a grader assessing relevance of a retrieved document to a user question.
                If the document contains keyword(s) or semantic meaning related to the question, filteredList it as relevant.
                """;

    public static String CheckHallucSystemPrompt = """
                You are a teacher grading a quiz.\s
                
                You will be given FACTS and a STUDENT ANSWER.\s
                
                Here is the grade criteria to follow:
                
                (1) Ensure the STUDENT ANSWER is grounded in the FACTS.\s
                
                (2) Ensure the STUDENT ANSWER does not contain "hallucinated" information outside the scope of the FACTS.
                
                Score:
                
                A score of yes means that the student's answer meets all of the criteria. This is the highest (best) score.\s
                
                A score of no means that the student's answer does not meet all of the criteria. This is the lowest possible score you can give.
                
                Explain your reasoning in a step-by-step manner to ensure your reasoning and conclusion are correct.\s
                
                Avoid simply stating the correct answer at the outset.
                """;

    public static String TableParsePrompt = """
            You are an expert in extracting useful information from IMAGE.
            With a given image, your task is to extract key entities, summarize them,
            and write useful information that can be used later for retrieval.
            """;

    public static String PageParsePrompt = """
            You are a highly advanced AI specializing in PDF document analysis and image processing.Your task is to parse a given PDF page image and extract the following elements:\s
            1.**Summary**: Generate a concise summary of the main content presented on the page.Focus on capturing the key points and themes in no more than 5 sentences.
            2.**Table Data**: Identify and extract any tables present on the page.For each table, provide the following: - Table title (if available) - Column headers - A structured representation of the data in a CSV format, maintaining the integrity of rows and columns.
            3.**Image Explanation**: Analyze any images found on the page.Provide a detailed description of each image, including: - The main subject of the image - The context or relevance of the image to the overall content of the page - Any notable features or elements within the image that contribute to its meaning.Ensure that the output is organized clearly, with appropriate headings for each section (Summary, Table Data, Image Explanation).The extracted information should be precise, relevant, and formatted for easy readability.
            """;

    public static String TableLocationPrompt = """
            You are a highly advanced AI specializing in PDF document analysis and image processing.Your task is to parse a given PDF page image and extract table coordinates as x, y, width, height for each table in the pdf page:\s
            """;



}
