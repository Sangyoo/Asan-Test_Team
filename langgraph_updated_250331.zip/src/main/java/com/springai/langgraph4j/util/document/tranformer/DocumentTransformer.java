package com.springai.langgraph4j.util.document.tranformer;

import org.springframework.ai.document.Document;

import java.util.List;
import java.util.function.Function;

public interface DocumentTransformer extends Function<List<Document>, List<Document>> {

    default List<Document> transform(List<Document> transform) {
        return apply(transform);
    }
}