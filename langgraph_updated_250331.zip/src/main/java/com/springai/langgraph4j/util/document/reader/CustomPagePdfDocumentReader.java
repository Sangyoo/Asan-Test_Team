package com.springai.langgraph4j.util.document.reader;

import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.document.Document;
import org.springframework.ai.reader.ExtractedTextFormatter;
import org.springframework.ai.reader.pdf.PagePdfDocumentReader;
import org.springframework.ai.reader.pdf.config.PdfDocumentReaderConfig;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
public class CustomPagePdfDocumentReader implements DocumentReader{
    @Override
    public List<Document> read() {
        return DocumentReader.super.read();
    }

    @Override
    public List<Document> get() {
        PagePdfDocumentReader pdfReader = new PagePdfDocumentReader("classpath:/static/SPRI_AI_Brief.pdf",
                PdfDocumentReaderConfig.builder()
                        .withPageTopMargin(0)
                        .withPageExtractedTextFormatter(ExtractedTextFormatter.builder()
                                .withNumberOfTopTextLinesToDelete(0)
                                .build())
                        .withPagesPerDocument(1)
                        .build());
        List<Document> documents = pdfReader.read();
        log.info(documents.getFirst().toString());
        return pdfReader.read();
    }

    public List<Document> get(String filePath) {
        PagePdfDocumentReader pdfReader = new PagePdfDocumentReader(filePath,
                PdfDocumentReaderConfig.builder()
                        .withPageTopMargin(0)
                        .withPageExtractedTextFormatter(ExtractedTextFormatter.builder()
                                .withNumberOfTopTextLinesToDelete(0)
                                .build())
                        .withPagesPerDocument(1)
                        .build());
        List<Document> documents = pdfReader.read();
        log.info(documents.getFirst().toString());
        return pdfReader.read();
    }

    public static void main(String[] args) {
        //
        CustomPagePdfDocumentReader customPagePdfDocumentReader = new CustomPagePdfDocumentReader();
        customPagePdfDocumentReader.get();
    }
}
