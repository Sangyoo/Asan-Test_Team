package com.springai.langgraph4j.util.document.reader;

import org.springframework.ai.document.Document;

import java.util.List;
import java.util.function.Supplier;

public interface DocumentReader extends Supplier<List<Document>> {

    default List<Document> read() {
        return get();
    }
}
