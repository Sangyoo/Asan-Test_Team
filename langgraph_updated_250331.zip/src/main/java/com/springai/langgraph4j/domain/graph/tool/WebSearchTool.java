package com.springai.langgraph4j.domain.graph.tool;

import dev.langchain4j.rag.content.retriever.ContentRetriever;
import dev.langchain4j.rag.content.retriever.WebSearchContentRetriever;
import dev.langchain4j.rag.query.Query;
import dev.langchain4j.web.search.WebSearchEngine;
import dev.langchain4j.web.search.tavily.TavilyWebSearchEngine;
import dev.langchain4j.rag.content.Content;
import lombok.Value;
import java.util.List;
import java.util.function.Function;

@Value( staticConstructor = "of")
public class WebSearchTool implements Function<String, List<Content>> {
    //
    String tavilyApiKey;

    public WebSearchTool(String tavilyApiKey) {
        this.tavilyApiKey = tavilyApiKey;
    }

    /**
     * Applies the query to a search engine and retrieves up to 3 results.
     *
     * @param query The search query to be executed.
     * @return A list of content items retrieved from the searchengine.
     */
    @Override
    public List<dev.langchain4j.rag.content.Content> apply(String query) {
        WebSearchEngine webSearchEngine = TavilyWebSearchEngine.builder()
                .apiKey(tavilyApiKey) // get a free key: https://app.tavily.com/sign-in
                .build();

        ContentRetriever webSearchContentRetriever = WebSearchContentRetriever.builder()
                .webSearchEngine(webSearchEngine)
                .maxResults(3)
                .build();

        return webSearchContentRetriever.retrieve( new Query( query ) );
    }
}
