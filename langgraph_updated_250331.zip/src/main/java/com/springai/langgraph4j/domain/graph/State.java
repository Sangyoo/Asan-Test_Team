package com.springai.langgraph4j.domain.graph;

import org.bsc.langgraph4j.state.AgentState;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static java.util.Collections.emptyList;

public class State extends AgentState {

    public State(Map<String, Object> initData) {
        super(initData);
    }

    public String question() {
        Optional<String> result = value("question");
        return result.orElseThrow( () -> new IllegalStateException( "question is not set!" ) );
    }
    public Optional<String> generation() {
        return value("generation");

    }
    public List<String> documents() {
        return this.<List<String>>value("documents").orElse(emptyList());
    }
}
