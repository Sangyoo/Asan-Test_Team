package com.springai.langgraph4j;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Langgraph4jApplication {

	public static void main(String[] args) {
		SpringApplication.run(Langgraph4jApplication.class, args);
	}

}
