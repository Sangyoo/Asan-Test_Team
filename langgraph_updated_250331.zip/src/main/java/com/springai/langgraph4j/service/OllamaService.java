package com.springai.langgraph4j.service;

import lombok.RequiredArgsConstructor;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.ollama.OllamaChatModel;
import org.springframework.ai.ollama.api.OllamaOptions;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class OllamaService {
    //
    private final OllamaChatModel ollamaChatModel;
    private final String MODEL_NAME = "llama3.1:8b";

    public String callLlavaModel(List<Message> messages) {
        //
        return this.ollamaChatModel.call(new Prompt(
                        messages,
                        OllamaOptions.builder()
                                .model("llava:7b")
                                .temperature(0.0)
                                .build()))
                .getResult().getOutput().getText();
    }

    public String callGemmaModel(List<Message> messages) {
        //
        return this.ollamaChatModel.call(new Prompt(
                        messages,
                        OllamaOptions.builder()
                                .model("gemma3:4b")
                                .temperature(0.0)
                                .build()))
                .getResult().getOutput().getText();
    }

    public String callOllamaModel(List<Message> messages) {
        //
        return this.ollamaChatModel.call(new Prompt(
                        messages,
                        OllamaOptions.builder()
                                .model(MODEL_NAME)
                                .temperature(0.0)
                                .build()))
                .getResult().getOutput().getText();
    }

    public String callOllamaModel(List<Message> messages, String modelName) {
        //
        return this.ollamaChatModel.call(new Prompt(
                        messages,
                        OllamaOptions.builder()
                                .model(modelName)
                                .temperature(0.0)
                                .build()))
                .getResult().getOutput().getText();
    }

    public String callOllamaModelJson(List<Message> messages) {
        //
        return this.ollamaChatModel.call(new Prompt(
                        messages,
                        OllamaOptions.builder()
                                .model(MODEL_NAME)
                                .temperature(0.0)
                                .format("json")
                                .build()))
                .getResult().getOutput().getText();
    }

    public String callOllamaModelJson(List<Message> messages, String modelName) {
        //
        return this.ollamaChatModel.call(new Prompt(
                        messages,
                        OllamaOptions.builder()
                                .model(modelName)
                                .temperature(0.0)
                                .format("json")
                                .build()))
                .getResult().getOutput().getText();
    }
}
