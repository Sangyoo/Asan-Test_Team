package com.springai.langgraph4j.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.springai.langgraph4j.domain.graph.State;
import com.springai.langgraph4j.util.prompt.SystemPrompt;
import com.springai.langgraph4j.util.prompt.UserPrompt;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class EdgeService {
    //
    private final OllamaService ollamaService;
    private String routerQuestion( State state ) throws JsonProcessingException {
        //
        log.info("=============> route questions ===================");
        String.format(UserPrompt.RouterUserPromptFormat, "Artificial Intelligence(AI) industry");
        String result = this.ollamaService.callOllamaModelJson(List.of(new UserMessage(UserPrompt.RouterUserPromptFormat)));

        log.info("=============> route result : {}", result);
        JsonNode jsonNode = new ObjectMapper().readTree(result);
        String datasource = jsonNode.get("datasource").asText();
        if(datasource.equals("websearch")) {
            return "web_search";
        }
        else {
            return "vector_search";
        }
    }

    public String decideToWebSearch( State state ) {
        //
        log.info("==============> checking if we need websearch...");
        return state.documents().isEmpty()? "web_search" : "generate";
    }

    public String checkHallucination( State state ) throws JsonProcessingException {
        //
        String userPrompt = String.format(UserPrompt.CheckHallucUserPromptFormat, state.documents(), state.question());
        List<Message> messages = List.of(new SystemMessage(SystemPrompt.CheckHallucSystemPrompt), new UserMessage(userPrompt));
        String result = this.ollamaService.callOllamaModelJson(messages);
        log.info("------------Hallucination RESULT : {}", result);
        JsonNode jsonNode = new ObjectMapper().readTree(result);
        String yesOrNo = jsonNode.get("binary_score").asText();
        int currentStep = (int) state.data().getOrDefault("current_step", 0);
        log.info("current_step : {}", currentStep);
        if(yesOrNo.equals("yes")) {
            log.info("==============> Hallucination Check passed, process will be ended");
            return "end";
        }
        else if(currentStep > 2) {
            log.info("==============> Max Tries exceeded, process will be ended");
            return "end";
        }
        else {
            log.info("==============> Hallucination detected, regenerate will be started");
            return "generate";
        }
    }
}
