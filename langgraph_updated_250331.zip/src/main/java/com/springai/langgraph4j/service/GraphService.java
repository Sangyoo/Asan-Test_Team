package com.springai.langgraph4j.service;

import com.springai.langgraph4j.domain.graph.State;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.bsc.langgraph4j.CompiledGraph;
import org.bsc.langgraph4j.GraphRepresentation;
import org.bsc.langgraph4j.GraphStateException;
import org.bsc.langgraph4j.StateGraph;
import org.bsc.langgraph4j.action.AsyncEdgeAction;
import org.springframework.stereotype.Service;

import static org.bsc.langgraph4j.StateGraph.END;
import static org.bsc.langgraph4j.StateGraph.START;
import static org.bsc.langgraph4j.action.AsyncNodeAction.node_async;
import static org.bsc.langgraph4j.utils.CollectionsUtils.mapOf;

@Service
@RequiredArgsConstructor
@Slf4j
public class GraphService {
    //
    private final NodeService nodeService;
    private final EdgeService edgeService;
    private final String WEB_SEARCH_NODE = "web_search";
    private final String VECTOR_SEARCH_NODE = "vector_search";
    private final String GRADE_NODE = "grade_document";
    private final String GENERATE_NODE = "generate";

    public StateGraph<State> getStateGraphWorkflow() throws GraphStateException {
        // workflow 생성
        StateGraph<State> workflow = new StateGraph<>(State::new)
                // Start
                .addNode(WEB_SEARCH_NODE, node_async(nodeService::webSearch))          // Web 검색
                .addNode(VECTOR_SEARCH_NODE, node_async(nodeService::vectorSearch))    // VectorDB 검색
                .addNode(GRADE_NODE, node_async(nodeService::grade))                   // 연관된 document  filtering
                .addNode(GENERATE_NODE, node_async(nodeService::generate))
//                .addConditionalEdges(
//                        START,
//                        AsyncEdgeAction.edge_async(this::routerQuestion),
//                        mapOf(
//                                "vector_search", VECTOR_SEARCH_NODE
//                                , "web_search", WEB_SEARCH_NODE
//                        )
//                )
                .addEdge(START, VECTOR_SEARCH_NODE)
                .addEdge(VECTOR_SEARCH_NODE, GRADE_NODE)
                .addConditionalEdges(
                        GRADE_NODE,
                        AsyncEdgeAction.edge_async(edgeService::decideToWebSearch),
                        mapOf(
                                "web_search", WEB_SEARCH_NODE
                                , "generate", GENERATE_NODE
                        )
                )
                .addEdge(WEB_SEARCH_NODE, GENERATE_NODE)
                .addConditionalEdges(
                        GENERATE_NODE,
                        AsyncEdgeAction.edge_async(edgeService::checkHallucination),
                        mapOf(
                                "end", END
                                , "generate", GRADE_NODE
                        )
                );
        return workflow;
    }

    public void printMermaidGraph(CompiledGraph<State> compiledGraph) {
        // FlowChart 출력
        GraphRepresentation graphDiagram = compiledGraph.getGraph(GraphRepresentation.Type.MERMAID, "Graph Diagram", false);
        /**
         * FlowChart 변환해서 보여주는 사이트
         * 아래 사이트에 graphDiagram.toString() 결과값 붙여넣으면 됩니다.
         * https://mermaid.live/
         * **/
        log.info(graphDiagram.toString());
    }

}
