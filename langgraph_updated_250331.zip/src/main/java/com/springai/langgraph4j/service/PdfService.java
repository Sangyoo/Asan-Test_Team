package com.springai.langgraph4j.service;

import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDResources;
import org.apache.pdfbox.pdmodel.graphics.PDXObject;
import org.apache.pdfbox.pdmodel.graphics.form.PDFormXObject;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.springframework.stereotype.Service;
import technology.tabula.ObjectExtractor;
import technology.tabula.Page;
import technology.tabula.PageIterator;
import technology.tabula.Table;
import technology.tabula.extractors.BasicExtractionAlgorithm;
import technology.tabula.extractors.SpreadsheetExtractionAlgorithm;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class PdfService {
    //
    public static final Float RENDER_DPI = 300f;

    public BufferedImage convertPdfToImage(String pdfPath, int pageIndex) throws IOException {
        try (PDDocument document = Loader.loadPDF(new File(pdfPath))) {
            PDFRenderer pdfRenderer = new PDFRenderer(document);
            int count = document.getPages().getCount();// 페이지 수
            System.out.println("Total pages: " + count);
            return pdfRenderer.renderImageWithDPI(pageIndex, RENDER_DPI); // 300 DPI로 렌더링
        }
    }
    public void saveImage(BufferedImage image, String outputPath) throws IOException {
        if(image == null) {
            System.out.println("Image is null");
            System.out.println("file path: " + outputPath);
            return;
        }
        ImageIO.write(image, "png", new File(outputPath));
    }

    public Map<Integer, List<Table>> extractTables(String pdfPath) throws IOException {
        File file = new File(pdfPath);
        ObjectExtractor extractor = new ObjectExtractor(Loader.loadPDF(file));
        SpreadsheetExtractionAlgorithm algorithm = new SpreadsheetExtractionAlgorithm(); // SpreadsheetExtraction : 격자기반 테이블 감지(lattice)
//        BasicExtractionAlgorithm algorithm = new BasicExtractionAlgorithm(); // basic : 여백기반 테이블 감지(Stream)
        Map<Integer, List<Table>> tableMap = new HashMap<>();
        try {
            PageIterator pages = extractor.extract();
            while (pages.hasNext()) {
                Page page = pages.next();
                int pageNumber = page.getPageNumber();
                List<Table> tables = algorithm.extract(page);
                tableMap.put(pageNumber, tables);
            }
        } finally {
            extractor.close();
        }
        return tableMap;
    }

    public List<BufferedImage> cropTableImage(BufferedImage fullImage, List<Table> tables, Float scale) {
        log.info("tables : {}", tables);
        if (tables.isEmpty()) {
            System.out.println("No tables found");
            return null;
        }

        List<BufferedImage> collect = tables.stream().map(table -> {
            // pdfRenderer를 통해 table을 이미지로 crop할때, 좌표, 수치를 DPI / 72.0f (pdf 기본 dpi) 만큼 Scale Up 필요
            int width = (int) (table.getWidth() * scale);
            int height = (int) (table.getHeight() * scale);
            int x = (int) (table.getRows().getFirst().getFirst().getLeft() * scale);
            int y = (int) (table.getRows().getFirst().getFirst().getTop() * scale);
            log.info("width : {} \n height : {} \n x : {} \n y : {} \n", width, height, x, y);
            return fullImage.getSubimage( x, y, width, height );
        }).toList();

        return collect;
    }

    public List<RenderedImage> getBufferedImageFromPage(PDResources resources) throws IOException {
        //
        List<RenderedImage> images = new ArrayList<>();
        for (COSName xObjectName : resources.getXObjectNames()) {
            PDXObject xObject = resources.getXObject(xObjectName);

            if (xObject instanceof PDFormXObject) {
                images.addAll(getBufferedImageFromPage(((PDFormXObject) xObject).getResources()));
            } else if (xObject instanceof PDImageXObject) {
                images.add(((PDImageXObject) xObject).getImage());
            }
        }

        return images;
    }
}
