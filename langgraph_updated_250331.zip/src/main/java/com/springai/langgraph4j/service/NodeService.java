package com.springai.langgraph4j.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.springai.langgraph4j.domain.graph.State;
import com.springai.langgraph4j.domain.graph.tool.WebSearchTool;
import com.springai.langgraph4j.util.prompt.SystemPrompt;
import com.springai.langgraph4j.util.prompt.UserPrompt;
import dev.langchain4j.rag.content.Content;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.document.Document;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.bsc.langgraph4j.utils.CollectionsUtils.listOf;
import static org.bsc.langgraph4j.utils.CollectionsUtils.mapOf;

@Service
@RequiredArgsConstructor
@Slf4j
public class NodeService {
    //
    private final VectorService vectorService;
    private final OllamaService ollamaService;

    /* Vector Store 검색 (현재 pgVector) */
    public Map<String, Object> vectorSearch( State state ) {
        log.info("---RETRIEVE START---");

        String question = state.question();
        List<Document> documents = this.vectorService.searchVector(question);

        documents.forEach( doc -> log.info("------------RETRIEVE RESULT : {}", doc.getText()) );
        List<String> retrieveTexts = documents.stream().map(Document::getText).collect(Collectors.toList());
        return mapOf( "documents", retrieveTexts);
    }

    /* tavily api를 이용한 web search */
    public Map<String,Object> webSearch(State state ) {
        log.info("---WEB SEARCH START---");

        String question = state.question();

        List<Content> result = WebSearchTool.of( "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" ).apply(question);

        String webResult = result.stream()
                .map( content -> content.textSegment().text() )
                .collect(Collectors.joining("\n"));
        log.info("------------WEB Search RESULT : {}", webResult);
        return mapOf( "documents", listOf( webResult ) );
    }

    public Map<String, Object> generate( State state ) {
        //
        String rag_prompt = String.format(UserPrompt.GeneratePromptFormat, String.join("\n", state.documents()), state.question());
        String result = this.ollamaService.callOllamaModel(List.of(new UserMessage(rag_prompt)));
        log.info("------------GENERATION RESULT : {}", result);
        int currentStep = (int) state.data().getOrDefault("current_step", 0);
        return mapOf( "generation", result, "current_step", currentStep+1);
    }

    public Map<String, Object> grade( State state ) {
        log.info("---GRADE START---");
        List<String> filteredList = new ArrayList<>();
        log.info("-- doucument size : " + state.documents().size());

        state.documents().forEach(document -> {
            String graderFormat = String.format(UserPrompt.GradeUserPromptFormat, document, state.question());
            List<Message> messages = List.of(new SystemMessage(SystemPrompt.GradeSystemPrompt), new UserMessage(graderFormat));
            String result = this.ollamaService.callOllamaModelJson(messages);
            log.info("------------GENERATION RESULT : {}", result);
            try {
                JsonNode jsonNode = new ObjectMapper().readTree(result);
                String yesOrNo = jsonNode.get("binary_score").asText();
                if (yesOrNo.equals("yes")) { filteredList.add(document); }
            } catch (JsonProcessingException e) {
                throw new RuntimeException(e);
            }
        });
        log.info("--- filtered list size : {}", filteredList.size());
        log.info("--- filtered list  : {}", filteredList);

        return mapOf( "documents", filteredList);
    }
}
