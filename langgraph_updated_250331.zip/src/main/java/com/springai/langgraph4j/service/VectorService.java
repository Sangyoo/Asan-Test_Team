package com.springai.langgraph4j.service;

import lombok.RequiredArgsConstructor;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class VectorService {
    //
    private final VectorStore pgVectorStore;

    public void addVector(List<Document> documents) {
        //
        pgVectorStore.add(documents);
    }

    public List<Document> searchVector(String question) {
        return pgVectorStore.similaritySearch(question);
    }
}
