package com.springai.langgraph4j.service;

import com.springai.langgraph4j.util.document.reader.CustomPagePdfDocumentReader;
import com.springai.langgraph4j.util.document.tranformer.CustomTokenTextSplitter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDResources;
import org.apache.pdfbox.pdmodel.graphics.PDXObject;
import org.apache.pdfbox.pdmodel.graphics.form.PDFormXObject;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.springframework.ai.document.Document;
import org.springframework.ai.embedding.EmbeddingOptions;
import org.springframework.ai.embedding.EmbeddingOptionsBuilder;
import org.springframework.ai.embedding.TokenCountBatchingStrategy;
import org.springframework.ai.ollama.OllamaEmbeddingModel;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import javax.imageio.ImageIO;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class DocumentService {
    //
    private final CustomPagePdfDocumentReader pdfDocumentReader;
    private final CustomTokenTextSplitter tokenTextSplitter;
    private final OllamaEmbeddingModel ollamaEmbeddingModel;
    private final VectorStore pgVectorStore;
    private final int MAX_DOCUMENT_BATCH_SIZE = 10000;
    private final EmbeddingOptions DEFAULT_EMBEDDING_OPTIONS
            = EmbeddingOptionsBuilder.builder().withDimensions(1536).withModel("bge-m3:latest").build();

    public List<Document> readPDFFile(String filePath) {
        //
        return pdfDocumentReader.get(filePath);
    }

    public List<Document> splitDocuments(List<Document> documents) {
        //
        return tokenTextSplitter.splitDocuments(documents);
    }

    public List<float[]> embeddingPDF(List<Document> documents, EmbeddingOptions options) {
        //
        if(options == null) {
            options = DEFAULT_EMBEDDING_OPTIONS;
        }

        TokenCountBatchingStrategy batchingStrategy = new TokenCountBatchingStrategy();
        List<float[]> embed = ollamaEmbeddingModel.embed(documents, options, batchingStrategy);
        return embed;
    }

    public void addPDFToVectorStore(List<Document> documents) {
        //
        pgVectorStore.add(documents);
    }

    public List<Document> search(String query) {
        return this.pgVectorStore.similaritySearch(SearchRequest.builder()
                .query(query).topK(2).build());
    }
    public PDDocument getPddDocument() throws IOException {
        //
//        ClassPathResource classPathResource = new ClassPathResource("static/sample_with_image.pdf");
        ClassPathResource classPathResource = new ClassPathResource("static/SPRI_AI_BRIEF.pdf");
        File file = classPathResource.getFile();
        PDDocument pdDocument = Loader.loadPDF(file);

        return pdDocument;
    }

    public void saveImageFile(RenderedImage image, String fileName) throws IOException {
        File outputFile = new File(fileName);
        ImageIO.write(image, "png", outputFile);
    }

    public List<RenderedImage> getImagesFromPDF(PDDocument document) throws IOException {
        List<RenderedImage> images = new ArrayList<>();
        for (PDPage page : document.getPages()) {
            images.addAll(getImagesFromResources(page.getResources()));
        }

        return images;
    }

    private List<RenderedImage> getImagesFromResources(PDResources resources) throws IOException {
        List<RenderedImage> images = new ArrayList<>();

        for (COSName xObjectName : resources.getXObjectNames()) {
            PDXObject xObject = resources.getXObject(xObjectName);

            if (xObject instanceof PDFormXObject) {
                images.addAll(getImagesFromResources(((PDFormXObject) xObject).getResources()));
            } else if (xObject instanceof PDImageXObject) {
                images.add(((PDImageXObject) xObject).getImage());
            }
        }

        return images;
    }
}
