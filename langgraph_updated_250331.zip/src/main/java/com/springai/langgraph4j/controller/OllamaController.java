package com.springai.langgraph4j.controller;

import com.springai.langgraph4j.service.OllamaService;
import com.springai.langgraph4j.util.prompt.SystemPrompt;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.model.Media;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.util.MimeTypeUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
@Slf4j
public class OllamaController {
    //
    private final OllamaService ollamaService;

    @GetMapping("/multi")
    public String multiModal() {
        //
        Message systemMessage = new SystemMessage(SystemPrompt.TableParsePrompt);
        Resource resource = new ClassPathResource("static/images/page1_image1_enhanced.png");

        // Media
        Media media = new Media(MimeTypeUtils.IMAGE_PNG, resource);
        Message userMessage = new UserMessage("explain this table", media);

        String result = ollamaService.callGemmaModel(List.of(systemMessage, userMessage));
        log.info("Multimodal Result : {}", result);

        return result;
    }
}
