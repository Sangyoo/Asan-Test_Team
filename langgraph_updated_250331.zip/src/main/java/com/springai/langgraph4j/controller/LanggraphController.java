package com.springai.langgraph4j.controller;

import com.springai.langgraph4j.domain.graph.State;
import com.springai.langgraph4j.service.EdgeService;
import com.springai.langgraph4j.service.GraphService;
import com.springai.langgraph4j.service.NodeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.bsc.langgraph4j.CompiledGraph;
import org.bsc.langgraph4j.GraphRepresentation;
import org.bsc.langgraph4j.StateGraph;
import org.bsc.langgraph4j.action.AsyncEdgeAction;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;
import java.util.Optional;

import static org.bsc.langgraph4j.StateGraph.END;
import static org.bsc.langgraph4j.StateGraph.START;
import static org.bsc.langgraph4j.action.AsyncNodeAction.node_async;
import static org.bsc.langgraph4j.utils.CollectionsUtils.mapOf;

@RequestMapping
@RestController
@RequiredArgsConstructor
@Slf4j
public class LanggraphController {
    //
    private final GraphService graphService;
    @GetMapping("/langgraph")
    public String test3(@RequestParam(value = "prompt") String prompt) throws Exception {
        // workflow 생성 & 컴파일
        CompiledGraph<State> app = this.graphService.getStateGraphWorkflow().compile();

        // FlowChart 출력
        this.graphService.printMermaidGraph(app);

        // graph 실행
        Optional<State> resultState = app.invoke(Map.of("question", prompt));

        // 응답 반환
        return resultState.map(state -> (String) state.data().getOrDefault("generation", "No Result"))
                .orElse("No result");
    }
}
