package com.springai.langgraph4j.controller;

import com.springai.langgraph4j.service.DocumentService;
import com.springai.langgraph4j.util.document.reader.CustomPagePdfDocumentReader;
import com.springai.langgraph4j.util.document.tranformer.CustomTokenTextSplitter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.document.Document;
import org.springframework.ai.model.Media;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

@RequestMapping
@RestController
@RequiredArgsConstructor
@Slf4j
public class PdfController {
    //

    private final CustomPagePdfDocumentReader pdfDocumentReader;
    private final CustomTokenTextSplitter tokenTextSplitter;
    private final DocumentService documentService;

    @GetMapping("/pdfbox")
    public void pdfBox() throws IOException {
        //
//        PDDocument pdDocument = pdfDocumentService.getPddDocument();
//        pdDocument.getPages().forEach(p);
//        Gson gson = new GsonBuilder().excludeFieldsWithModifiers(Modifier.PRIVATE).create();
//        log.info("pdDocument : {}", gson.toJson(pdDocument, PDDocument.class));

//        List<RenderedImage> images = pdfDocumentService.getImagesFromPDF(pdDocument);
//        File file = new File("src/main/resources/static/images");
//        if(!file.exists()) {
//            file.mkdir();
//        }
//        log.info("file path : {}", file.getPath());
//        log.info("file absolute path : {}", file.getAbsolutePath());
//        pdDocument.close();
//        pdfDocumentService.saveImageFile(
//                images.getFirst(),
//                file.getPath() + "/testImage.png"
//        );
    }

    @GetMapping("/pdfsearch")
    public void pdfSearch(@RequestParam(value = "prompt")String prompt) throws IOException {
        //
        List<Document> search = documentService.search(prompt);
        log.info(search.getFirst().getText());
        Media media = search.getFirst().getMedia();
        if (media != null) {
            // PNG 파일로 저장
            try (FileOutputStream fos = new FileOutputStream("retrieved_image.png")) {
                fos.write(media.getDataAsByteArray());
            }
            System.out.println("Image retrieved and saved as retrieved_image.png");
        }
//        PDDocument pdDocument = pdfDocumentService.getPddDocument();
//        pdDocument.getPages().forEach(p);
//        Gson gson = new GsonBuilder().excludeFieldsWithModifiers(Modifier.PRIVATE).create();
//        log.info("pdDocument : {}", gson.toJson(pdDocument, PDDocument.class));

//        List<RenderedImage> images = pdfDocumentService.getImagesFromPDF(pdDocument);
//        File file = new File("src/main/resources/static/images");
//        if(!file.exists()) {
//            file.mkdir();
//        }
//        log.info("file path : {}", file.getPath());
//        log.info("file absolute path : {}", file.getAbsolutePath());
//        pdDocument.close();
//        pdfDocumentService.saveImageFile(
//                images.getFirst(),
//                file.getPath() + "/testImage.png"
//        );
    }

    @GetMapping("/pdf")
    public void test() {
        // read pdf
        String filePath = "classpath:/static/SPRI_AI_Brief.pdf";
        log.info("====================== filePath : {}", filePath);
        log.info("====================== pdf read start");
        List<Document> documents = this.documentService.readPDFFile(filePath);
        log.info("====================== documentSize : {}", documents.size());

        // split pdf
        log.info("====================== split start");
        List<Document> splitDocuments = this.documentService.splitDocuments(documents);
        log.info("====================== documentSize : {}", splitDocuments.size());

        //embedding
//        EmbeddingOptions embeddingOptions = EmbeddingOptionsBuilder.builder().build();
//        EmbeddingResponse response = embeddingModel.call(new EmbeddingRequest(splitDocuments.stream().map(d -> d.getText()).toList(), embeddingOptions));
//        log.info("============================> embedding response metadata : {}", response.getMetadata()                                                                                                                                                                                                                                                                       );
//        log.info("============================> embedding response result : {}", response.getResult());

        // ollama embedding & vector Store add
        this.documentService.addPDFToVectorStore(splitDocuments);

      // vector store search
//        List<Document> retrieveDocuments = this.vectorStore.similaritySearch(SearchRequest.builder()
//                .query("International Code of Conduct for Advanced AI Systems").topK(5).build());
//
//        log.info("====================== retrieveDocuments 1 content : {}", retrieveDocuments.getFirst().getFormattedContent());

    }
    public List<Document> read() {
        String filePath = "classpath:/static/SPRI_AI_Brief.pdf";
        log.info("====================== filePath : {}", filePath);
        log.info("====================== pdf read start");
        List<Document> documents = pdfDocumentReader.get(filePath);
        log.info("====================== documentSize : {}", documents.size());
        return documents;
    }

    public List<Document> split(List<Document> documents) {
        log.info("====================== split start");
        List<Document> resultDocs = tokenTextSplitter.splitDocuments(documents);
        log.info("====================== documentSize : {}", resultDocs.size());
        return resultDocs;
    }

    public static void main(String[] args) {
        //
        CustomPagePdfDocumentReader pdfReader = new CustomPagePdfDocumentReader();
        CustomTokenTextSplitter tokenTextSplitter = new CustomTokenTextSplitter();

        // read pdf
        String filePath = "classpath:/static/SPRI_AI_Brief.pdf";
        log.info("====================== filePath : {}", filePath);
        log.info("====================== pdf read start");
        List<Document> documents = pdfReader.get(filePath);
        log.info("====================== documentSize : {}", documents.size());

        // split pdf
        log.info("====================== split start");
        List<Document> splitDocumentst = tokenTextSplitter.splitDocuments(documents);
        log.info("====================== documentSize : {}", splitDocumentst.size());
    }

}
