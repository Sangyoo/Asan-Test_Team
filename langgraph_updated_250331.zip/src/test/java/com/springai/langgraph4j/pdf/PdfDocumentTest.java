package com.springai.langgraph4j.pdf;

import com.springai.langgraph4j.domain.graph.State;
import com.springai.langgraph4j.service.DocumentService;
import com.springai.langgraph4j.service.OllamaService;
import com.springai.langgraph4j.service.PdfService;
import com.springai.langgraph4j.util.prompt.SystemPrompt;
import dev.langchain4j.model.ollama.OllamaChatModel;
import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.document.Document;
import org.springframework.ai.document.id.RandomIdGenerator;
import org.springframework.ai.model.Media;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.util.MimeTypeUtils;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@Slf4j
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class PdfDocumentTest {
    //
    @Autowired
    private OllamaService ollamaService;
    @Autowired
    private DocumentService documentService;
    private static PDDocument pdDocument;
    private static String pdfPath;
    private final int SAMPLE_PAGE_INDEX = 0;
    private Document document;
    private State state;
    @BeforeAll
    public static void setUp() throws IOException {
        //
//        ClassPathResource classPathResource = new ClassPathResource("static/SPRI_AI_BRIEF.pdf");
        ClassPathResource classPathResource = new ClassPathResource("static/RESFL_sample.pdf");
        File file = classPathResource.getFile();
        pdDocument = Loader.loadPDF(file);
        pdfPath = file.getPath();
    }

    @Test
    @DisplayName("pdf 페이지에서 텍스트 추출")
    public void pdfPageTextTest() throws IOException {
        // 페이지 번호
        AtomicInteger index = new AtomicInteger(SAMPLE_PAGE_INDEX+1);
//        ForkPDFLayoutTextStripper pdfTextStripper = new ForkPDFLayoutTextStripper();
        PDFTextStripper pdfTextStripper = new PDFTextStripper();

        pdfTextStripper.setStartPage(index.get());
        pdfTextStripper.setEndPage(index.get());

        String pdfTextStripperText = null;
        try {
            pdfTextStripperText = pdfTextStripper.getText(pdDocument);
            log.info("page Number : {}, pdfTextStripperText : {}", index, pdfTextStripperText);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        index.getAndIncrement();
    }

    @Test
    @DisplayName("pdf 페이지에서 텍스트 추출, summary 생성 후 Document 생성")
    public void pdfPageToDocumentTest() throws IOException {
        // 페이지 번호
        AtomicInteger index = new AtomicInteger(SAMPLE_PAGE_INDEX+1);
//        ForkPDFLayoutTextStripper pdfTextStripper = new ForkPDFLayoutTextStripper();
        PDFTextStripper pdfTextStripper = new PDFTextStripper();

        pdfTextStripper.setStartPage(index.get());
        pdfTextStripper.setEndPage(index.get());

        String pdfTextStripperText = null;
        try {
            pdfTextStripperText = pdfTextStripper.getText(pdDocument);
            log.info("page Number : {}, pdfTextStripperText : {}", index, pdfTextStripperText);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        assertFalse(pdfTextStripperText.isEmpty());

        Message systemMessage = new SystemMessage(SystemPrompt.TableParsePrompt);
        Resource resource = new ClassPathResource("static/images/page1_image1_enhanced.png");

        // Media
        Media media = new Media(MimeTypeUtils.IMAGE_PNG, resource);
        Message userMessage = new UserMessage("explain this table", media);

        String result = assertDoesNotThrow(() -> ollamaService.callGemmaModel(List.of(systemMessage, userMessage)));
        log.info("Multimodal Result : {}", result);

        Document pdfPageDocument = new Document((new RandomIdGenerator()).generateId(new Object[0], result, media, new HashMap<>()));
        assertDoesNotThrow(() -> this.documentService.addPDFToVectorStore(List.of(pdfPageDocument)));
    }

    @Test
    @DisplayName("VLM에게 페이지 전체 요약 요청")
    void pdfSum() {
        //
        Message systemMessage = new SystemMessage(SystemPrompt.PageParsePrompt);
        Resource resource = new ClassPathResource("static/images/0page.png");

        // Media
        Media media = new Media(MimeTypeUtils.IMAGE_PNG, resource);
        Message userMessage = new UserMessage("explain this table", media);
        String result = assertDoesNotThrow(() -> ollamaService.callGemmaModel(List.of(systemMessage, userMessage)));
        log.info("Multimodal Result : {}", result);
        /*****Summary**

         The page details bitumen prices across Europe, Africa, the Middle East, and Asia-Pacific for the week of September 25th to October 1st, 2021.  Bitumen cargo values increased across these regions, driven by gains in crude and fuel oil. Domestic truck prices in Europe have also strengthened.  The report highlights price fluctuations in specific locations, influenced by factors like crude oil prices, regional demand, and supply chain dynamics.  The Asia-Pacific market remained relatively stable despite some disruptions due to Chinese holidays.

         **Table Data**

         Here's a breakdown of the tables present on the page, including their titles, headers, and data in CSV format.

         **1. Bitumen Prices at Key Locations (25 Sep-1 Oct)**

         *   **Table Title:** Bitumen Prices at Key Locations (25 Sep-1 Oct)
         *   **Column Headers:** Location, Export Prices FOB, Delivered Prices CFR, Truck Prices, Unit
         *   **CSV Data:**

         ```csv
         Location,Export Prices FOB,Delivered Prices CFR,Truck Prices,Unit
         Mediterranean,448.58,nc,nc,$/t
         Rotterdam,460.90,nc,nc,$/t
         Baltic,453.90,nc,nc,$/t
         Singapore,405,415,nc,$/t
         South Korea,395,405,nc,$/t
         Middle East,298,nc,nc,$/t
         North Africa,nc,496,nc,$/t
         East Africa,nc,nc,nc,$/t
         West Africa,nc,600,nc,$/t
         East China,nc,475,nc,$/t
         Domestic,nc,nc,507,$/t
         Southern Germany,nc,nc,480,$/t
         Italy,nc,nc,480,$/t
         France,nc,nc,480,$/t
         Spain,nc,nc,480,$/t
         United Kingdom,nc,nc,480,$/t
         Poland,nc,nc,480,$/t
         ```

         **2. Price Change (Week-on-Week)**

         *   **Table Title:** Price Change (Week-on-Week)
         *   **Column Headers:** Location, Export Prices FOB, Delivered Prices CFR, Truck Prices
         *   **CSV Data:**

         ```csv
         Location,Export Prices FOB,Delivered Prices CFR,Truck Prices
         Mediterranean,+20.93,nc,nc
         Rotterdam,+18.95,nc,nc
         Baltic,+18.95,nc,nc
         Singapore,+5.00,nc,nc
         South Korea,nc,nc,nc
         Middle East,+5.50,nc,nc
         North Africa,+18.00,nc,nc
         East Africa,+26.00,nc,nc
         West Africa,+21.00,nc,nc
         East China,-2.50,nc,nc
         Domestic,nc,nc,nc
         Southern Germany,nc,nc,nc
         Italy,nc,nc,nc
         France,nc,nc,nc
         Spain,nc,nc,nc
         United Kingdom,nc,nc,nc
         Poland,nc,nc,nc
         ```

         **Image Explanation**

         The image is a page from a market report titled "Argus Asphalt Report" focusing on bitumen prices.

         *   **Main Subject:** The primary subject is a table displaying bitumen prices across various locations in Europe, Africa, the Middle East, and Asia-Pacific.
         *   **Context/Relevance:** The report provides a snapshot of the bitumen market, which is a key component in asphalt production for road construction and maintenance. The prices reflect supply and demand dynamics, crude oil prices, and regional economic factors.
         *   **Notable Features:**
         *   The report uses abbreviations like "FOB" (Free On Board) and "CFR" (Cost and Freight) to denote pricing terms.
         *   "nc" (not captured) is used to indicate that data was not available for a specific location or price category.
         *   The report highlights price changes week-on-week, providing insight into market trends.
         *   The report includes a summary at the top, providing a brief overview of the key market developments.

         Let me know if you'd like me to elaborate on any specific aspect of this information!
         */
    }

    @Test
    @DisplayName("VLM에게 페이지 테이블 좌표 요청")
    void pdfLocationTest() {
        //
        Message systemMessage = new SystemMessage(SystemPrompt.TableLocationPrompt);
        Resource resource = new ClassPathResource("static/images/0page.png");

        // Media
        Media media = new Media(MimeTypeUtils.IMAGE_PNG, resource);
        Message userMessage = new UserMessage("This is an Image of PDF Page, parse it and tell me the location of tables in this page", media);
        String result = assertDoesNotThrow(() -> ollamaService.callGemmaModel(List.of(systemMessage, userMessage)));
        log.info("Multimodal Result : {}", result);
    }

    @Test
    @DisplayName("PDF to VectorStore")
    void pdfTest() {
        // 1. pdf를 분석해서(크면 split) layout을 분리해냄 (meta정보 포함)

        // 2. meta정보를 포함한 layout을 바탕으로 Document 생성

        //    filepath: str  # path
        //    filetype: str  # pdf
        //    page_numbers: list[int]  # page numbers
        //    batch_size: int  # batch size
        //    split_filepaths: list[str]  # split files
        //    analyzed_files: list[str]  # analyzed files
        //    page_elements: dict[int, dict[str, list[dict]]]  # page elements
        //    page_metadata: dict[int, dict]  # page metadata
        //    page_summary: dict[int, str]  # page summary
        //    images: list[str]  # image paths
        //    images_summary: list[str]  # image summary
        //    tables: list[str]  # table
        //    tables_summary: dict[int, str]  # table summary
        //    texts: list[str]  # text
        //    texts_summary: list[str]  # text summary
    }
}
