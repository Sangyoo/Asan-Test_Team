package com.springai.langgraph4j.pdf;


import com.springai.langgraph4j.service.PdfService;
import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.ai.reader.pdf.layout.ForkPDFLayoutTextStripper;
import org.springframework.core.io.ClassPathResource;
import technology.tabula.Table;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;

@Slf4j
class PdfBoxTest {
    //
    private static final PdfService pdfService = new PdfService();
    private static PDDocument pdDocument;
    private static String pdfPath;
    private final Float SCALE = 300 / 72.0f;
    private final String TABLE_IMAGE_NAME_FORMAT = "src/main/resources/static/images/re_page%s_image%s.png";
    private final int SAMPLE_PAGE_INDEX = 10;

    @BeforeAll
    public static void setUp() throws IOException {
        //
//        ClassPathResource classPathResource = new ClassPathResource("static/SPRI_AI_BRIEF.pdf"); // 테이블 인식 완(19페이지)
//        ClassPathResource classPathResource = new ClassPathResource("static/sample-report.pdf"); // 테이블 인식 가능, 불완전
        ClassPathResource classPathResource = new ClassPathResource("static/RESFL_sample.pdf"); // 테이블 인식 불가
        File file = classPathResource.getFile();
        pdDocument = Loader.loadPDF(file);
        pdfPath = file.getPath();
    }

    @Test
    @DisplayName("pdfbox 페이지에서 텍스트 추출")
    public void pdfPageTextTest() throws IOException {
        // 페이지 번호
        AtomicInteger index = new AtomicInteger(SAMPLE_PAGE_INDEX + 1);
        ForkPDFLayoutTextStripper pdfTextStripper = new ForkPDFLayoutTextStripper();

        pdfTextStripper.setStartPage(index.get());
        pdfTextStripper.setEndPage(index.get());

        String pdfTextStripperText = null;
        try {
            pdfTextStripperText = pdfTextStripper.getText(pdDocument);
            log.info("page Number : {}, pdfTextStripperText : {}", index, pdfTextStripperText);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        index.getAndIncrement();
    }

    @Test
    @DisplayName("pdf 페이지에서 이미지 추출")
    public void pdfPageImageTest() throws IOException {
        // 페이지 번호
        AtomicInteger pageNum = new AtomicInteger(20);
        AtomicInteger imageIndex = new AtomicInteger(0);
        PDPage page = pdDocument.getPage(pageNum.get());
        List<RenderedImage> bufferedImageFromPage = pdfService.getBufferedImageFromPage(page.getResources());
        bufferedImageFromPage.forEach(image -> {
            String fileName = String.format(TABLE_IMAGE_NAME_FORMAT, pageNum, imageIndex.incrementAndGet());
            File outputFile = new File(fileName);
            try {
                ImageIO.write(image, "png", outputFile);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
    }

    @Test
    @DisplayName("pdf에서 테이블 데이터 추출")
    public void pdfPageTableExtractTest() throws IOException {
        //
        Map<Integer, List<Table>> integerListMap = pdfService.extractTables(pdfPath);
        log.info("integerListMap : {}", integerListMap.toString());
        assertAll("tableMap",
                () -> {
                    assertAll("contains 19 page",
                            () -> assertFalse(integerListMap.isEmpty()),
                            () -> assertTrue(integerListMap.containsKey(19))
                    );
                }
        );
    }

    @Test
    @DisplayName("pdf 페이지를 이미지로 변환")
    public void pdfPageConvertTest() throws IOException {
        //
        BufferedImage fullImage = pdfService.convertPdfToImage(pdfPath, SAMPLE_PAGE_INDEX);
        pdfService.saveImage(fullImage, "src/main/resources/static/images/0Page.png");
        File file = new File("src/main/resources/static/images/0Page.png");
        assertAll("file 저장", () -> assertTrue(file.exists()), () -> assertTrue(file.length() > 0));
    }

    @Test
    @DisplayName("pdf 페이지에서 테이블 좌표로 테이블 이미지 crop")
    public void pdfPageTableCrop() throws IOException {
        // 샘플 페이지의 table을 이미지로 crop
        Map<Integer, List<Table>> integerListMap = pdfService.extractTables(pdfPath);
        assertFalse(integerListMap.isEmpty());
        log.info("PageTableListMap : {}", integerListMap.toString());
        // 페이지 이미지로 저장
        BufferedImage fullPageImage = pdfService.convertPdfToImage(pdfPath, SAMPLE_PAGE_INDEX);
//        pdfService.saveImage(fullPageImage, "src/main/resources/static/images/fullPage.png");
//        File file = new File("src/main/resources/static/images/fullPage.png");
//        assertAll("file 저장", () -> assertTrue(file.exists()), () -> assertTrue(file.length() > 0));
        //
        AtomicInteger index = new AtomicInteger(SAMPLE_PAGE_INDEX+1);
        integerListMap.forEach((key, value) -> {
//            if (key != SAMPLE_PAGE_INDEX+1 || value.isEmpty()) return;
            List<BufferedImage> bufferedImages = pdfService.cropTableImage(fullPageImage, value, SCALE);
            bufferedImages.forEach(image -> {
                try {
                    pdfService.saveImage(image, String.format(TABLE_IMAGE_NAME_FORMAT, SAMPLE_PAGE_INDEX+1, index));
                } catch (IOException e) {
                    throw new RuntimeException(e);
                } finally {
                    index.incrementAndGet();
                }
            });
        });
    }

    @AfterAll
    public static void tearDownAll() throws IOException {
        //
        pdDocument.close();
    }
}
