package com.springai.langgraph4j;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Langgraph4jApplicationTests {

	@Test
	void contextLoads() {

	}

}
