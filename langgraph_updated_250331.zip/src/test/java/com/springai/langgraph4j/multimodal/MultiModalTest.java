package com.springai.langgraph4j.multimodal;


import com.springai.langgraph4j.service.OllamaService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.model.Media;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.util.MimeTypeUtils;

import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertFalse;


@SpringBootTest
public class MultiModalTest {
    //
    @Autowired
    private OllamaService ollamaService;
    @Test
    @DisplayName("Multimodal LLM에게 질문하기")
    void MultimodalServiceTest() throws IOException {
        //
        Message systemMessage = new SystemMessage("You are an helpful Table Image Analyzer. Analyze the Image provided.");
        Resource resource = new ClassPathResource("static/images/page19_image1.png");

        // Media
        Media media = new Media(MimeTypeUtils.IMAGE_PNG, resource);
        Message userMessage = new UserMessage("Can you explain what this table means?", media);

        String result = assertDoesNotThrow(() -> ollamaService.callLlavaModel(List.of(systemMessage, userMessage)));
        System.out.println("Multimodal Result : {}" + result);

        assertFalse(result.isEmpty());
    }
}
