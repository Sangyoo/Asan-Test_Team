package com.springai.langgraph4j.service;

import org.apache.pdfbox.cos.COSDictionary;
import org.apache.pdfbox.pdmodel.PDResources;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import technology.tabula.Table;

import java.awt.image.BufferedImage;
import java.awt.image.IndexColorModel;
import java.awt.image.RenderedImage;
import java.util.List;
import java.util.Map;

class PdfServiceTest {
    PdfService pdfService = new PdfService();

    @Test
    void testConvertPdfToImage() {
        BufferedImage result = pdfService.convertPdfToImage("pdfPath", 0);
        Assertions.assertEquals(new BufferedImage(0, 0, 0, new IndexColorModel(0, 0, new int[]{0}, 0, true, 0, 0)), result);
    }

    @Test
    void testSaveImage() {
        pdfService.saveImage(new BufferedImage(0, 0, 0, new IndexColorModel(0, 0, new int[]{0}, 0, true, 0, 0)), "outputPath");
    }

    @Test
    void testExtractTables() {
        Map<Integer, List<Table>> result = pdfService.extractTables("pdfPath");
        Assertions.assertEquals(Map.of(Integer.valueOf(0), List.of(new Table(0f, 0f, 0f, 0f))), result);
    }

    @Test
    void testCropTableImage() {
        List<BufferedImage> result = pdfService.cropTableImage(new BufferedImage(0, 0, 0, new IndexColorModel(0, 0, new int[]{0}, 0, true, 0, 0)), List.of(new Table(0f, 0f, 0f, 0f)), Float.valueOf(1.1f));
        Assertions.assertEquals(List.of(new BufferedImage(0, 0, 0, new IndexColorModel(0, 0, new int[]{0}, 0, true, 0, 0))), result);
    }

    @Test
    void testGetBufferedImageFromPage() {
        List<RenderedImage> result = pdfService.getBufferedImageFromPage(new PDResources(new COSDictionary()));
        Assertions.assertEquals(List.of(null), result);
    }
}

//Generated with love by TestMe :) Please raise issues & feature requests at: https://weirddev.com/forum#!/testme