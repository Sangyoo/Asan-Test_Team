# 유튜브 판다스 스튜디오 [바로가기](https://www.youtube.com/channel/UCh-c-LFH9Q6VbHRRqD4oLOA)

### 재생목록: 랭체인 응용하기 실습파일을 공유합니다. 
- 랭체인(LangChain) + 올라마(Ollama) 활용 예제 
