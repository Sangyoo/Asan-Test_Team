import ChatGoogleGenerativeAI as genai

# Google Cloud 프로젝트 ID 또는 API 키 설정 필요
# genai.configure(api_key="YOUR_API_KEY")

try:
    models = genai.list_models()
    for model in models:
        print(model.name)
except Exception as e:
    print(f"모델 목록을 가져오는 중 오류 발생: {e}")