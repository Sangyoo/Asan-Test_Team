import os

# 사용할 모델을 환경 변수에서 가져오도록 설정 (기본값: "gemini")
MODEL_NAME = os.getenv("MODEL_NAME", "gemini")

def get_model():
    """사용할 모델을 반환하는 함수"""
    if MODEL_NAME == "claude":
        from langchain_anthropic import ChatAnthropic
        return ChatAnthropic(model="claude-3-7-sonnet-latest", temperature=0.1, max_tokens=20000)
    
    elif MODEL_NAME == "gemini":
        from langchain_google_genai import ChatGoogleGenerativeAI
        return ChatGoogleGenerativeAI(model="gemini-2.0-flash-001")
        # return ChatGoogleGenerativeAI(model="gemini-1.5-pro-latest")

    else:
        raise ValueError(f"지원되지 않는 모델: {MODEL_NAME}")