from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from langgraph.prebuilt import create_react_agent
from langchain_mcp_adapters.tools import load_mcp_tools
from langchain_anthropic import ChatAnthropic
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_teddynote.messages import astream_graph

# Anthropic의 Claude 모델 초기화
# model = ChatAnthropic(
#     model_name="claude-3-7-sonnet-latest", temperature=0, max_tokens=20000
# )

model = ChatGoogleGenerativeAI(model="gemini-1.5-pro-latest")

async def main():
    server_params = StdioServerParameters(
        command="D:\\ai-workspace\\langgraph-mcp-agents-master\\langgraph-mcp-agents-master\\.venv\\Scripts\\python.exe",
        args=["D:\\ai-workspace\\langgraph-mcp-agents-master\\langgraph-mcp-agents-master\\mcp_server_local.py"]
    )
    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            # 연결 초기화
            await session.initialize()
            # MCP 도구 로드
            tools = await load_mcp_tools(session)
            print(tools)
            # 에이전트 생성
            agent = create_react_agent(model, tools)
            # 에이전트 응답 스트리밍
            await astream_graph(agent, {"messages": "서울의 날씨는 어떠니?"})

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())