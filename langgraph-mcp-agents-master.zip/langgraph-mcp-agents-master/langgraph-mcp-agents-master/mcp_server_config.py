async def server_config():
    predefined_mcp_config = {
        "weather": {
            "command": "uv",
            "args": ["run", "mcp_server_local.py"],
            "transport": "stdio",
        },
        "tavily-mcp": {
            "command": "cmd.exe",
            "args": [
                "/c",
                "npx",
                "-y",
                "tavily-mcp@0.1.4",
                "run",
                "tavily-mcp"
            ],
            "transport": "stdio"
        },
        "sequential-thinking": {
            "command": "cmd.exe",
            "args": [
                "/c",
                "npx",
                "-y",
                "@modelcontextprotocol/server-sequential-thinking"
            ],
            "transport": "stdio"
        },
        "intellij-mcp": {
            "command": "cmd.exe",
            "args" :[
                "/c",
                "npx",
                "-y",
                "@jetbrains/mcp-proxy"
            ],
            "transport": "stdio"
        },
        "filesystem": {
            "command": "cmd.exe",
            "args" :[
                "/c",
                "npx",
                "-y",
                "@modelcontextprotocol/server-filesystem",
                "D:\\ai-workspace"
            ],
            "transport": "stdio"
        }
    }
    return predefined_mcp_config
