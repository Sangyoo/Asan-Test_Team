rm -r .parcel-cache
rm -r dist
bun run parcel:build

