# 🦜🕸️ LangGraph4j Studio

An **embed playground webapp** that runs a Langgraph4j workflow in visual way.