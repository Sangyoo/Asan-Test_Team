# Langgraph4j and SpringAI AgentExecutor sample

This sample shows how to use Langgraph4j with SpringAI.

## Setup

Set API KEYs

```properties
spring.ai.openai.api-key=${OPENAI_API_KEY}
weather.api-key=${WEATHER_API_KEY}
weather.api-url=https://api.weatherapi.com/v1
```