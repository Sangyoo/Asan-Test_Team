package org.bsc.assemblyai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MindmapApplicationTests {

	@Test
	void contextLoads() {
	}

}
