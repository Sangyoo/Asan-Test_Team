package io.vizend.graphqlsecond;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GraphqlsecondApplicationTests {

    @Test
    void contextLoads() {
    }

}
