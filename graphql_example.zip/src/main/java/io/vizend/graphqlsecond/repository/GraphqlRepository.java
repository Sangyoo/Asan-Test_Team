package io.vizend.graphqlsecond.repository;

public interface GraphqlRepository {
}
