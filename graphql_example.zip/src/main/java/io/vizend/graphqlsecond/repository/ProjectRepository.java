package io.vizend.graphqlsecond.repository;

import io.vizend.graphqlsecond.domain.Project;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.graphql.data.GraphQlRepository;

import java.util.Optional;

@GraphQlRepository
public interface ProjectRepository extends JpaRepository<Project, String> {

    Optional<Project> findBySlug(String slug);
}
