package io.vizend.graphqlsecond.service;

import io.vizend.graphqlsecond.domain.CreateProjectInput;
import io.vizend.graphqlsecond.domain.Project;
import io.vizend.graphqlsecond.domain.UpdateProjectInput;
import io.vizend.graphqlsecond.repository.ProjectRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ProjectService {

    @Autowired
    private ProjectRepository projectRepository;

    // greeting 쿼리
    @QueryMapping
    public String getGreeting(String name) {
        return "Hello, " + name;
    }

    // project 쿼리
    @QueryMapping
    public Optional<Project> getProjectBySlug(String slug) {
        return projectRepository.findBySlug(slug);
    }

    // createProject 메서드
    @MutationMapping
    public Project createProject(CreateProjectInput input) {
        Project project = new Project();
        project.setName(input.getName());
        project.setRepositoryUrl(input.getRepositoryUrl());
        project.setStatus(input.getStatus());
        return projectRepository.save(project);
    }

    public Project createManual(Project project) {
        //
        return projectRepository.save(project);
    }

    // updateProject 메서드
    @MutationMapping
    public Project updateProject(String slug, UpdateProjectInput input) {
        Project project = projectRepository.findBySlug(slug)
                .orElseThrow(() -> new RuntimeException("Project not found"));

        if (input.getName() != null) {
            project.setName(input.getName());
        }
        if (input.getRepositoryUrl() != null) {
            project.setRepositoryUrl(input.getRepositoryUrl());
        }
        if (input.getStatus() != null) {
            project.setStatus(input.getStatus());
        }

        return projectRepository.save(project);
    }

    // deleteProject 메서드
    @MutationMapping
    public boolean deleteProject(String slug) {
        Project project = projectRepository.findBySlug(slug)
                .orElseThrow(() -> new RuntimeException("Project not found"));

        projectRepository.delete(project);
        return true;
    }
}
