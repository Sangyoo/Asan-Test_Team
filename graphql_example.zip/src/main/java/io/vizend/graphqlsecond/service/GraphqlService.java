package io.vizend.graphqlsecond.service;

public class GraphqlService {
}
