package io.vizend.graphqlsecond.resolver;

public class ProjectQueryResolver{
}
