package io.vizend.graphqlsecond.domain;

public enum ProjectStatus {
    ACTIVE,
    COMMUNITY,
    INCUBATING,
    ATTIC,
    EOL
}
