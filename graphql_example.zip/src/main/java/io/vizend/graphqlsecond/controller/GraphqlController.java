package io.vizend.graphqlsecond.controller;

import io.vizend.graphqlsecond.domain.Project;
import io.vizend.graphqlsecond.service.ProjectService;
import lombok.RequiredArgsConstructor;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping
@RequiredArgsConstructor
public class GraphqlController {
    //
    private final ProjectService projectService;
//    @QueryMapping
//    public String greeting(@Argument String name) {return name;}
    @PostMapping
    public void generateProject() {
        //
        Project project = new Project();
        project.setName("Vizend");
        projectService.create
    }

//    @SchemaMapping(typeName = "Query", value = "greeting")
//    public String greeting(@Argument String name) {return "your name is " + name;}
}
