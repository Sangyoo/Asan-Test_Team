package io.vizend.graphqlsecond;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GraphqlsecondApplication {

    public static void main(String[] args) {
        SpringApplication.run(GraphqlsecondApplication.class, args);
    }

}
